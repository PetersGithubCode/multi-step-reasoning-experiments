import torch
torch.cuda.is_available()

import os
import torch
import torch.nn as nn
import bitsandbytes as bnb
from transformers import AutoTokenizer, AutoConfig, AutoModelForCausalLM, BitsAndBytesConfig
import json
from datasets import load_dataset, load_from_disk, Dataset, DatasetDict
from transformers import pipeline
import numpy as np
from peft import LoraConfig, get_peft_model
from trl import DPOConfig
from trl import DPOTrainer
from torch.utils.data import DataLoader
import shutil

#remove old trained model
rm_path = "/home/peternicholson/Documents/C-4-b-HpQA/gemma_dpo_train"
if os.path.exists(rm_path):
    shutil.rmtree(rm_path)

#declaration of paths
local_model_path = "/home/peternicholson/Documents/gemma-2-9b-it"
local_dir = "/home/peternicholson/Documents/C-4-b-HpQA/"
dpo_traj_dir = '/home/peternicholson/Documents/C-3-b-HpQA/'
evaluation_model_name = 'gemma3:27b'


with open(dpo_traj_dir + 'updated_best_worst_experiment_entries-2.json', 'r') as f:
    traj_dictionary = json.load(f)

trained_data = []
for traj in traj_dictionary:
    entry = {
        'prompt': traj['train_ready_trajectory'],
        'chosen': traj['best_action'],
        'rejected': traj['worst_action']
    }
    trained_data.append(entry)

full_dataset = Dataset.from_list(trained_data)
print(f"Full dataset size: {len(full_dataset)}")

#90/10 split
#train_test_split = full_dataset.train_test_split(test_size=0.1, seed=42)

#full set
dpo_dataset_splits = DatasetDict({
    'train': full_dataset
})

print(f"Training set size: {len(dpo_dataset_splits['train'])}")
print(f"Validation set size: {len(dpo_dataset_splits['validation'])}")



bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_double_quant=True,
    bnb_4bit_compute_dtype=torch.float16,
)

model = AutoModelForCausalLM.from_pretrained(
    local_model_path,
    quantization_config=bnb_config,
    device_map='auto',
)
model.config.use_cache = False

tokenizer = AutoTokenizer.from_pretrained(local_model_path)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = 'right'

lora_r = 32
lora_alpha = 64
lora_dropout = 0.1

peft_config = LoraConfig(
    r=8,
    lora_alpha=16,
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
)

args = DPOConfig(
  output_dir=os.path.join(local_dir, "gemma_dpo_train"),
  num_train_epochs=3,
  per_device_train_batch_size=1,
  gradient_accumulation_steps=32,
  gradient_checkpointing=True,
  optim="paged_adamw_8bit",
  warmup_steps=17,
  logging_steps=10,
  loss_type="sigmoid",
  eval_strategy="no",
  eval_steps=50,
  save_steps=50,
  learning_rate=1e-5,
  lr_scheduler_type='cosine',
  remove_unused_columns=False,
  max_length=384,
  max_prompt_length=128
)

dpo_trainer = DPOTrainer(
    model=model,
    ref_model=None,
    args=args,
    beta=0.1,
    peft_config=peft_config,
    train_dataset=dpo_dataset_splits,
    eval_dataset=None,
    tokenizer=tokenizer,
)

print("Starting DPO training...")
dpo_trainer.train()
print("Training finished. Saving model...")
dpo_trainer.save_model()
print("Model saved successfully.")
