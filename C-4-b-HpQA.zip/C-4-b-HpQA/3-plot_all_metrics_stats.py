import os
import json
import matplotlib.pyplot as plt
from collections import defaultdict



# Path to the trainer state file from your last checkpoint
# Make sure to update this path to your specific checkpoint
#TRAINER_STATE_PATH = "/home/peternicholson/Documents/C-4-b-HpQA/gemma_dpo_train/checkpoint-168/"
#output_dir = "/home/peternicholson/Documents/C-4-b-HpQA/gemma_dpo_train/checkpoint-168/plots"
trainer_dir = "/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/ubuntu-Runs/3/C-4-b-HpQA/"


def plot_metrics_from_trainer_state(file_path, output_dir):

    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from the file '{file_path}'.")
        return

    log_history = data.get("log_history")
    if not log_history:
        print("Error: 'log_history' not found in the JSON file.")
        return

    metrics = defaultdict(lambda: {'steps': [], 'values': []})

    for entry in log_history:
        step = entry.get("step")
        if step is None:
            continue

        for key, value in entry.items():
            if isinstance(value, (int, float)) and key != 'step':
                metrics[key]['steps'].append(step)
                metrics[key]['values'].append(value)

    if not metrics:
        print("No plottable metrics found in the log_history.")
        return

    os.makedirs(output_dir, exist_ok=True)
    print(f"Saving charts to '{output_dir}/' directory...")

    for metric_name, data in metrics.items():
        plt.figure(figsize=(10, 6))

        plt.plot(data['steps'], data['values'], marker='o', linestyle='-')
        plt.title(f"Metric: {metric_name}")
        plt.xlabel("Step")
        plt.ylabel("Value")
        plt.grid(True)

        safe_filename = metric_name.replace('/', '_') + ".png"
        file_save_path = os.path.join(output_dir, safe_filename)

        plt.savefig(file_save_path)

        plt.close()

    print("All individual charts saved successfully.")

    num_metrics = len(metrics)
    cols = 2 if num_metrics > 1 else 1
    rows = (num_metrics + cols - 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(7 * cols, 5 * rows), squeeze=False)
    axes = axes.flatten()

    for i, (metric_name, data) in enumerate(metrics.items()):
        ax = axes[i]
        ax.plot(data['steps'], data['values'], marker='.', linestyle='-')
        ax.set_title(metric_name)
        ax.set_xlabel("Step")
        ax.set_ylabel("Value")
        ax.grid(True)

    for i in range(num_metrics, len(axes)):
        fig.delaxes(axes[i])

    plt.tight_layout()
    print("Displaying combined plot window...")
    plt.show()

if __name__ == "__main__":
    plot_metrics_from_trainer_state(trainer_dir + "trainer_state.json", trainer_dir + "metrics_charts")

