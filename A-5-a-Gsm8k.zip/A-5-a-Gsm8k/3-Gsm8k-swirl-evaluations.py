# In[ ]:
import os
import ollama
import json
import random
import re
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel
from trl import AutoModelForCausalLMWithValueHead
import yaml
import Gsm8kMathaticalReasoningCalcToolTrajectories

# In[ ]:
A_5_a = '/home/peternicholson/Documents/A-5-a-Gsm8k/'

# In[ ]:

model_judge = "gemma3:27b"
base_line_model_path = "/home/peternicholson/Documents/gemma-2-9b"
trained_ppo_model_path = "/home/peternicholson/Documents/A-4-a-Gsm8k/ppo_offline_rl_final_adapter"
trained_dpo_model_path = "/home/peternicholson/Documents/C-4-a-Gsm8k/gemma_dpo_train"
A_5_a = '/home/peternicholson/Documents/'
test_data_file = "gsm8k_test.jsonl"


# In[ ]:
def extract_questions_and_answers_gsm8k(f_gsm8k_300test_set):
    # get all contexts as paragraphs in a list of strings
    f_qa_pairs = []
    id_counter = 0
    # loop the whole set
    for item in f_gsm8k_300test_set:
        # extract into a dictionary: id, question and answer
        f_qa_pairs.append({
            'id': id_counter,
            'question': item['question'],
            'answer': item['answer']
        })
        # so that we have a way to reference the answer later on
        id_counter += 1
    return f_qa_pairs


def write_out_file_json_dump(f_name, f_action, f_list):
    with open(f_name, f_action, encoding="utf-8") as f_file:
        json.dump(f_list, f_file, indent=1)



def build_outcome_filtering_query(f_question, f_answer_key, f_trajectories_answer):
    f_query = (f"<start_of_turn>user\n"
               f"I need you to help me grade the answer to the following question: \"{f_question} \".\n"
               f"The answer key says: \"{f_answer_key} \", and my answer is: \" {f_trajectories_answer} \" . Am I correct?\n"
               f"Please explain your reasoning and then answer \"YES\" or \"NO\".\n"
               f"There are multiple ways to write the same answer. For example, \"10\", \"10.00\", \"$10\", and \"$10.00\" are all equivalent\n"
               f"<end_of_turn>\n")

    return f_query


def prompt_interchangeable_model(f_prompt, f_tokenizer, f_model):
    inputs = f_tokenizer(f_prompt, return_tensors="pt").to(f_model.device)
    # dynamically set the length
    input_len = inputs["input_ids"].shape[1]
    eos_token_id = f_tokenizer.convert_tokens_to_ids("<end_of_turn>")
    outputs = f_model.generate(
        **inputs,
        max_new_tokens=50,
        eos_token_id=eos_token_id,
        pad_token_id=eos_token_id,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,

    )
    generated_tokens = outputs[0][input_len:]
    f_gen_answer = f_tokenizer.decode(generated_tokens, skip_special_tokens=True)

    return f_gen_answer


def post_ollama_eval_model(f_query, f_model):
    f_messages = [
        {"role": "user", "content": f_query}
    ]
    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False)
    f_assistant_response = f_response['message']['content']
    # print(f"Assistant: {assistant_response}")

    return f_assistant_response


def query_the_llm(f_query, f_model_name):
    # post the query, get the response, update the trajectories
    f_response = post_ollama_eval_model(f_query, f_model_name)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


def log_eval(f_question, f_eval_prompt, f_response, f_outcome, f_det_name):
    f_entry = {
        "question": f_question,
        "eval prompt": f_eval_prompt,
        "response": f_response,
        "outcome": f_outcome
    }
    with open(f_det_name, 'a', encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)


def combine_trajectories(f_base, b_ppo_trained, b_dpo_trained):
    f_base_dict = {d['id']: d for d in f_base}
    f_ppo_trained_dict = {d['id']: d for d in b_ppo_trained}
    f_dpo_trained_dict = {d['id']: d for d in b_dpo_trained}
    common_ids = f_base_dict.keys() & f_ppo_trained_dict.keys() & f_dpo_trained_dict.keys()

    f_comb_traj = []
    for id in common_ids:
        a_base_inst = f_base_dict[id]
        b_ppo_inst = f_ppo_trained_dict[id]
        b_dpo_inst = f_dpo_trained_dict[id]

        combined = {
            'id': id,
            'question': a_base_inst['question'],
            'golden_answer': a_base_inst['golden_answer'],
            'base_trajectories': a_base_inst['trajectories'],
            'ppo_trajectories_trained': b_ppo_inst['trajectories'],
            'dpo_trajectories_trained': b_dpo_inst['trajectories'],
        }
        f_comb_traj.append(combined)

    return sorted(f_comb_traj, key=lambda x: x['id'])

# In[ ]:

def extract_final_response(f_trajectory):
    answer_value = None
    # start at the end of trajectory, structure will be <eos><end_of_turn><answer></answer><start_of_turn>model
    # remove \n lines
    f_trajectory = f_trajectory.replace('\n', '')
    # get start position of <answer>
    start_marker = f_trajectory.rfind('<answer>')
    # add 8
    start_marker = start_marker + 8
    # get the end position </answer> from the end of the <answer>
    end_marker = f_trajectory.find('</answer>', start_marker)
    answer_value = f_trajectory[start_marker:end_marker]

    return answer_value


def final_response_evaluated_correct(f_final_response):
    # remove astrix and funny punctuation - noticed some responses have ***YES*** or ***NO***
    f_final_response = re.sub(r'[\*\_\[\]\(\)\{\}]', '', f_final_response)
    # make it all lowercase
    f_final_response = f_final_response.lower()
    # only check the last 70 chars as the response will have an explanation at the beginning
    last_70_of_final_response = f_final_response[-70:]

    print(f_final_response)
    # match them as individual words with space
    f_yes = bool(re.search(r'\byes\b', last_70_of_final_response))
    f_no = bool(re.search(r'\bno\b', last_70_of_final_response))

    if f_yes:
        return True
    elif f_no:
        return False
    else:
        return -1

def evaluate_predicted_against_answer(f_question, f_golden_answer, f_answer, f_model_judge):
    query = build_outcome_filtering_query(f_question, f_golden_answer, f_answer)
    response, base_formatted_response = query_the_llm(query, f_model_judge)
    outcome = final_response_evaluated_correct(response)

    return outcome, base_formatted_response

def evaluate_set(f_list):
    counter = {"base": 0, "ppo_trained": 0,  "dpo_trained": 0}
    for entry in f_list:
        id = entry['id']
        question = entry['question']
        golden_answer = entry['golden_answer']
        base_trajectories = entry['base_trajectories']
        ppo_trajectories = entry['ppo_trajectories_trained']
        dpo_trajectories = entry['dpo_trajectories_trained']
        base_answer = extract_final_response(base_trajectories)
        ppo_answer = extract_final_response(ppo_trajectories)
        dpo_answer = extract_final_response(dpo_trajectories)

        # get outcome for base_trajectories
        base_outcome, base_formatted_response = evaluate_predicted_against_answer(question, golden_answer, base_answer, model_judge)
        if base_outcome:
            counter["base"] = counter["base"] + 1

        # get outcome for trained_trajectories
        ppo_outcome, ppo_formatted_response = evaluate_predicted_against_answer(question, golden_answer, ppo_answer, model_judge)
        if ppo_outcome:
            counter["ppo_trained"] = counter["ppo_trained"] + 1

        # get outcome for trained_trajectories
        dpo_outcome, dpo_formatted_response = evaluate_predicted_against_answer(question, golden_answer, dpo_answer, model_judge)
        if dpo_outcome:
            counter["dpo_trained"] = counter["dpo_trained"] + 1

        # log results
        f_entry = {
            "id": id,
            "question": question,
            "golden_answer": golden_answer,
            "base_trajectories": base_trajectories,
            "base_answer": base_answer,
            "base_formatted_response": base_formatted_response,
            "base_outcome": base_outcome,
            "ppo_trained_trajectories": ppo_trajectories,
            "ppo_trained_answer": ppo_answer,
            "ppo_trained_formatted_response": ppo_formatted_response,
            "ppo_trained_outcome": ppo_outcome,
            "dpo_trained_trajectories": dpo_trajectories,
            "dpo_trained_answer": dpo_answer,
            "dpo_trained_formatted_response": dpo_formatted_response,
            "dpo_trained_outcome": dpo_outcome,
        }
        with open(A_5_a + '6_Gsm8k-eval_outcome_log.json', 'a', encoding="utf-8") as f_file:
            json.dump(f_entry, f_file, indent=1)

    return counter


# In[ ]:
# page 8: experiment was run on a different random subsample of 300 examples
gsm8k_test_set = []
gsm8k_300_test_set = []
try:
    with open(A_5_a + test_data_file, 'r', encoding='utf-8') as f:
        for line in f:
            # Strip whitespace, any newline character
            stripped_line = line.strip()
            # line is not empty after stripping
            if stripped_line:
                try:
                    data_object = json.loads(stripped_line)
                    gsm8k_test_set.append(data_object)
                except json.JSONDecodeError as e:
                    print(f"Error decoding JSON from line: '{stripped_line}'")
                    print(f"Error message: {e}")

    # Select 300 random items from gsm8k_test_set
    if len(gsm8k_test_set) >= 300:
        gsm8k_300_test_set = random.sample(gsm8k_test_set, 300)
    else:
        print(f"Error: gsm8k_test_set contains only {len(gsm8k_test_set)} items, cannot select 300")
except FileNotFoundError:
    print(f"Error: The file was not found at {A_5_a + test_data_file}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")


q_lines = str(A_5_a + '6-Gsm8k_300random.txt')

# In[ ]:
print("extract_questions_and_answers_gsm8k...")
qa_pairs = extract_questions_and_answers_gsm8k(gsm8k_300_test_set)
print("qa_pairs: " + str(len(qa_pairs)))
print("finished")


# In[ ]:
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)

base_model = AutoModelForCausalLM.from_pretrained(
    base_line_model_path,
    quantization_config=quant_config,
    device_map="auto",
)

base_tokenizer = AutoTokenizer.from_pretrained(base_line_model_path)
if base_tokenizer.pad_token is None:
    base_tokenizer.pad_token = base_tokenizer.eos_token

# generate base_line trajectories
print("generate_baseline_trajectories...")
base_line_trajectories = Gsm8kMathaticalReasoningCalcToolTrajectories.generate_trajectories(qa_pairs, q_lines, base_model, base_tokenizer)
torch.cuda.empty_cache()
print("finished")


# In[ ]:
# generate trained ppo trajectories
print("Applying adapter to trained model...")
trained_ppo_inf_model = PeftModel.from_pretrained(base_model, trained_ppo_model_path)
print("Loading tokenizer...")
saved_inf_tokenizer = AutoTokenizer.from_pretrained(trained_ppo_model_path)

if saved_inf_tokenizer.pad_token is None:
    saved_inf_tokenizer.pad_token = saved_inf_tokenizer.eos_token
print("Model and tokenizer loaded trained model")

print("generate_trained_trajectories...")
# trained trajectories
trained_ppo_model_trajectories = Gsm8kMathaticalReasoningCalcToolTrajectories.generate_trajectories(qa_pairs, q_lines,
                                                                                                trained_ppo_inf_model,
                                                                                                saved_inf_tokenizer)
torch.cuda.empty_cache()
print("finished")


# In[ ]:
# generate trained dpo trajectories
print("Applying adapter to trained model...")
trained_dpo_inf_model = PeftModel.from_pretrained(base_model, trained_dpo_model_path)
print("Loading tokenizer...")
saved_inf_tokenizer = AutoTokenizer.from_pretrained(trained_dpo_model_path)

if saved_inf_tokenizer.pad_token is None:
    saved_inf_tokenizer.pad_token = saved_inf_tokenizer.eos_token
print("Model and tokenizer loaded trained model")

print("generate_trained_trajectories...")
# trained trajectories
trained_dpo_model_trajectories = Gsm8kMathaticalReasoningCalcToolTrajectories.generate_trajectories(qa_pairs, q_lines,
                                                                                                trained_dpo_inf_model,
                                                                                                saved_inf_tokenizer)
torch.cuda.empty_cache()
print("finished")



# In[ ]:
traject_base_and_trained_models = combine_trajectories(base_line_trajectories, trained_ppo_model_trajectories, trained_dpo_model_trajectories)


# In[ ]:
print("evaluate_set...")
results_counter = evaluate_set(traject_base_and_trained_models)
#print("base count: " + str(results_counter["base"]) + " vs trained count: " + str(results_counter["trained"]))

# In[ ]:
print("finished")

# In[ ]:
