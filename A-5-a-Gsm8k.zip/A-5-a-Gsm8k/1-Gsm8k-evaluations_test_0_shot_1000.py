# In[ ]:
# paper: Gemma 2: Improving Open Language Models at a Practical Size
# Table 13.

# GSM8K(Benchmark) 5-shot(metric) 68.6 (Gemma-2 9B)

# In[ ]:
# pip install transformers torch accelerate datasets tqdm

# In[ ]:
import torch
from transformers import BitsAndBytesConfig, AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from tqdm import tqdm
import re
import os
from datetime import datetime
from peft import PeftModel
import gc


# In[ ]:
local_model_path = "/home/peternicholson/Documents/gemma-2-9b-it"
local_Gsm8k_path = "/home/peternicholson/Documents/Gsm8k-dataset/grade-school-math-master/grade_school_math/data/"
general_path = "/home/peternicholson/Documents/A-5-a-Gsm8k/"
output_base_eval_file = "0_shot_base_line_evaluation_results.txt"
output_ppo_eval_file = "0_shot_trained_ppo_model_evaluation_results.txt"
output_dpo_eval_file = "0_shot_trained_dpo_model_evaluation_results.txt"
trained_ppo_model_path = "/home/peternicholson/Documents/A-4-a-Gsm8k/ppo_offline_rl_final_adapter"
trained_dpo_model_path = "/home/peternicholson/Documents/C-4-a-Gsm8k/gemma_dpo_train"


num_fewshot = 0
batch_size = 1
max_new_tokens = 300
subset_size = 1000


# In[ ]:
def create_prompt(test_question):
    prompt = ""
    for example in few_shot_examples:
        prompt += f"Question: {example['question']}\n"
        prompt += f"Answer: {example['answer']}\n\n"

    prompt += f"Question: {test_question}\n"
    prompt += "Answer:"
    return prompt


def extract_final_answer(model_output):
    match = re.search(r"####\s*([\d,]+\.?\d*)", model_output)
    if match:
        final_answer = match.group(1).replace(",", "")
        try:
            return float(final_answer)
        except ValueError:
            return None

    all_numbers = re.findall(r"[\d,]+\.?\d*", model_output)
    if all_numbers:
        last_number = all_numbers[-1].replace(",", "")
        try:
            return float(last_number)
        except ValueError:
            return None

    return None


def write_header(file_handle, model_path, num_fewshot):
    file_handle.write("GSM8K Evaluation Results\n")
    file_handle.write(f"Model Path: {model_path}\n")
    file_handle.write(f"Evaluation Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    file_handle.write(f"Number of Few-shot Examples: {num_fewshot}\n")
    file_handle.write("-" * 30 + "\n\n")


def write_question_result(file_handle, question_num, is_correct, question, model_output, predicted_answer,
                          ground_truth_answer):
    file_handle.write(f"Question #{question_num}\n")
    file_handle.write(f"Result: {'CORRECT' if is_correct else 'INCORRECT'}\n")
    file_handle.write(f"Question: {question}\n")
    file_handle.write(f"\nModel Full Output:\n\n{model_output}\n\n")
    file_handle.write(f"\nPredicted Answer: {predicted_answer}\n")
    file_handle.write(f"Ground Truth Answer: {ground_truth_answer}\n")
    file_handle.write("=" * 30 + "\n\n")


def write_summary(file_handle, total, correct, accuracy):
    summary_string = (
        "\nFINAL SUMMARY\n"
        f"Total Questions Evaluated: {total}\n"
        f"Correct Predictions: {correct}\n"
        f"Accuracy: {accuracy:.2f}%\n"
    )
    file_handle.write(summary_string)
    return summary_string

def process_evalaute(f_test_set, f_out_put_file, f_model_path, f_model, f_tokenizer, f_shots):
    print(f"Starting evaluation on {len(f_test_set)} test examples...")
    correct_predictions = 0
    total_predictions = 0
    with open(f_out_put_file, 'w', encoding='utf-8') as f:
        write_header(f, f_model_path, f_shots)

        for test_example in tqdm(f_test_set):
            total_predictions += 1
            question = test_example["question"]
            ground_truth_answer_text = test_example["answer"]
            ground_truth_answer = extract_final_answer(ground_truth_answer_text)

            if ground_truth_answer is None:
                print(f"Warning: Could not parse ground truth answer for question: {question}")
                f.write(f"--- Question #{total_predictions}: SKIPPED (Could not parse ground truth) ---\n")
                continue

            prompt = create_prompt(question)
            inputs = tokenizer(prompt, return_tensors="pt").to(f_model.device)

            with torch.no_grad():
                outputs = f_model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=True,
                    temperature=0.7,
                    pad_token_id=tokenizer.eos_token_id
                )

            full_output = f_tokenizer.decode(outputs[0], skip_special_tokens=True)
            model_answer_text = full_output[len(prompt):].strip()
            predicted_answer = extract_final_answer(model_answer_text)

            is_correct = False
            if predicted_answer is not None:
                if predicted_answer == ground_truth_answer:
                    is_correct = True

            if is_correct:
                correct_predictions += 1

            write_question_result(
                f, total_predictions, is_correct, question,
                model_answer_text, predicted_answer, ground_truth_answer
            )

        if total_predictions > 0:
            accuracy = (correct_predictions / total_predictions) * 100
        else:
            accuracy = 0

        final_summary = write_summary(f, total_predictions, correct_predictions, accuracy)

    print(final_summary)
    print(f"Detailed report saved to '{f_out_put_file}'")


# In[ ]:
#set up data for evaluation
print("load GSM8K dataset")
train_file = os.path.join(local_Gsm8k_path, "train.jsonl")
test_file = os.path.join(local_Gsm8k_path, "test.jsonl")
train_set = load_dataset('json', data_files=train_file, split='train')
test_set = load_dataset('json', data_files=test_file, split='train')
print(f"Successfully loaded {len(train_set)} training examples and {len(test_set)} test examples.")

print("Test set type:", type(test_set))
print("First example in test_set:", test_set[0])
print("Keys in first example:", test_set[0].keys())

few_shot_examples = train_set.select(range(num_fewshot))

#for evaluation select 300
test_set = test_set.select(range(min(subset_size, len(test_set))))


# In[ ]:
# set up base model
print(f"Loading tokenizer from local path: {local_model_path}")
tokenizer = AutoTokenizer.from_pretrained(local_model_path)
print(f"Loading model from local path: {local_model_path}")

quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)

base_model = AutoModelForCausalLM.from_pretrained(
    local_model_path,
    quantization_config=quant_config
)

print("Base Model initialization complete.")
base_model.eval()

#evaluate Base line
print("evaluate_baseline...")
out_put_file = general_path + output_base_eval_file
process_evalaute(test_set, out_put_file, local_model_path, base_model, tokenizer, num_fewshot)


#evalute PPO
# generate trained ppo trajectories
print("Applying adapter to trained ppo model...")
trained_ppo_model = PeftModel.from_pretrained(base_model, trained_ppo_model_path)
print("Loading tokenizer...")
saved_ppo_tokenizer = AutoTokenizer.from_pretrained(trained_ppo_model_path)

if saved_ppo_tokenizer.pad_token is None:
    saved_ppo_tokenizer.pad_token = saved_ppo_tokenizer.eos_token
print("ppo model and tokenizer loaded trained ppo model")
out_put_file = general_path + output_ppo_eval_file
process_evalaute(test_set, out_put_file, trained_ppo_model_path, trained_ppo_model, saved_ppo_tokenizer, num_fewshot)

#clean up memory to avoid running out
print("\nClearing ppo model from memory...")
del trained_ppo_model
del saved_ppo_tokenizer
gc.collect()
torch.cuda.empty_cache()
print("Memory cleared.\n")

#evalute DPO
# generate trained ppo trajectories
print("Applying adapter to trained dpo model...")
trained_dpo_model = PeftModel.from_pretrained(base_model, trained_dpo_model_path)
print("Loading tokenizer...")
saved_dpo_tokenizer = AutoTokenizer.from_pretrained(trained_dpo_model_path)

if saved_dpo_tokenizer.pad_token is None:
    saved_dpo_tokenizer.pad_token = saved_dpo_tokenizer.eos_token
print("ppo model and tokenizer loaded trained dpo model")
out_put_file = general_path + output_dpo_eval_file
process_evalaute(test_set, out_put_file, trained_dpo_model_path, trained_dpo_model, saved_dpo_tokenizer, num_fewshot)


#clean up memory to avoid running out
print("\nClearing dpo model from memory...")
del trained_dpo_model
del saved_dpo_tokenizer
gc.collect()
torch.cuda.empty_cache()
print("Memory cleared.\n")

# In[ ]:

