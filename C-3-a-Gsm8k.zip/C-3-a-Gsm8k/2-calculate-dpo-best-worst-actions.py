# In[ ]:
import json
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import torch
import ollama
import time
import re
import os

# In[ ]:
local_dir = '/home/peternicholson/Documents/C-3-a-Gsm8k/'
main_dir = '/home/peternicholson/Documents/'
evaluation_model_name = 'gemma3:27b'


file_path = local_dir + "updated_best_worst_experiment_entries-2.json"
if os.path.exists(file_path):
    os.remove(file_path)


# In[ ]:

def prepare_trajectory(f_traj):
    # remove last action: go to end of string and go back to the last instance of "<start_of_turn>model" and remove everything after
    last_model_index = f_traj.rfind("<start_of_turn>model")
    # get the original action
    f_a_action = f_traj[last_model_index:]
    # clean it
    f_b_action = f_a_action.replace("model\n", "").replace("<eos>\n", "")
    # remove the last action
    f_updated_traj = f_traj[:last_model_index + len("<start_of_turn>model")]

    return f_updated_traj, f_b_action


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


def query_the_llm(f_query, f_model_name):
    # post the query, get the response, update the trajectories
    f_response = post_llm(f_query, f_model_name)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def post_llm(f_query, f_model):
    f_messages = [
        {
            'role': 'system',
            'content': 'You are a helpful AI assistant',
        },
        {"role": "user", "content": f_query}
    ]
    options = {
        'temperature': 0.0,  # Forces greedy decoding
        'top_p': 1.0  # Disables nucleus sampling
    }
    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False, options=options)
    f_assistant_response = f_response['message']['content']

    return f_assistant_response


def extract_best(f_string):
    best = ""
    pattern_b = r"<best>(.*?)</best>"
    matches_b = re.search(pattern_b, f_string)

    if matches_b:
        best = matches_b.group(1)

    return best


def build_filtering_best(f_question, f_conversation, f_action_list):
    f_query = (f"<start_of_turn>user\n"
               #f"From the following question: {f_question}\n ,"
               f"From the following conversation: {f_conversation}\n."
               f"With the following list of responses {f_action_list}\n." 
               f"The best response should be with in <seach_query> tags and most useful to the conversation. Pick the best response and return only that response exactly as it is:'")


    return f_query

def build_filtering_worst(f_question, f_conversation, f_action_list):
    f_query = (f"<start_of_turn>user\n"
               #f"From the following question: {f_question}\n ,"
               f"From the following conversation: {f_conversation}\n."
               f"From the following list of responses {f_action_list}\n." 
               f"Pick the worst response that does NOT follow on from the conversation and return only that response exactly as it is, unchanged and nothing else:'")


    return f_query


def evaluate_response_model_check(f_response, f_model_name):
    f_prompt = (
        f"The following response was to rate an answer. Please check the response and return, the word GOOD if the rating was good, the word BAD if the rating was bad or the word NONE if it did not say. Response: {f_response}")
    f_response, f_formatted_response = query_the_llm(f_prompt, f_model_name)

    # make it all lowercase
    string_to_clean = f_response.lower()
    # remove astrix and funny punctuation - noticed some responses have ***YES*** or ***NO***
    response_to_check = re.sub(r'[\*\_\[\]\(\)\{\}]', '', string_to_clean)

    # match them as individual words with space
    f_good = bool(re.search(r'\bgood\b', response_to_check))
    f_bad = bool(re.search(r'\bbad\b', response_to_check))

    if f_good:
        return 1
    elif f_bad:
        return 0
    else:
        # causes problems
        # return -1
        return 0


def get_action_by_id(traj_dict, action_id):

    if "actions" not in traj_dict:
        raise KeyError("The dictionary does not contain an 'actions' key")

    for action_dict in traj_dict["actions"]:
        id_as_string = action_dict["id"]
        if id_as_string == action_id:
            return action_dict["action"]

    return None


# In[ ]:
with open(local_dir + 'updated_dpo_experiment_entries.json', 'r') as f:
    traj_dictionary = json.load(f)

i = 0
training_prepared_list = []
for question in traj_dictionary:
    print("i: " + str(i))
    i += 1
    quest = question['question']
    traj = question['trajectories']

    flat_action_list = ""
    for actions in question["actions"]:
        flat_action_list = flat_action_list + actions['action'] + ", "
    #prompt for the best action
    query_for_best = build_filtering_best(quest, traj, flat_action_list)
    best_response, best_formatted_response = query_the_llm(query_for_best, evaluation_model_name)
    print("best response: " + best_response)

    #prompt for the worst action
    query_for_worst = build_filtering_worst(quest, traj, flat_action_list)
    worst_response, best_formatted_response = query_the_llm(query_for_worst, evaluation_model_name)
    print("worst response: " + worst_response)

    #worst_action = get_action_by_id(question, str(worst))
    # save it
    entry = {
        "question": quest,
        "train_ready_trajectory": traj,
        "best_action": best_response,
        "worst_action": worst_response,
    }

    path = os.path.join(local_dir, "updated_best_worst_experiment_entries-2.json")
    if os.path.exists(path) and os.path.getsize(path) > 0:
        with open(path, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = []
    else:
        data = []
    if not isinstance(data, list):
        data = [data]
    data.append(entry)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# In[ ]:
print("finished")
