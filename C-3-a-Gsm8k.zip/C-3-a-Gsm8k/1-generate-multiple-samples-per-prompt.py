# In[ ]:
import json
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import torch
import ollama
import time
import re
import os

# In[ ]:
local_dir = '/home/peternicholson/Documents/C-3-a-Gsm8k/'
main_dir = '/home/peternicholson/Documents/'
inf_model_path = "/home/peternicholson/Documents/gemma-2-9b-it/"
A_3_a_Gsm8k_dir = '/home/peternicholson/Documents/A-3-a-Gsm8k/'
evaluation_model_name = 'gemma3:27b'

file_path = local_dir + "updated_dpo_experiment_entries.json"
if os.path.exists(file_path):
    os.remove(file_path)

# In[ ]:
# load the base model in quantized to 4bit use as inference model
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)
inf_model = AutoModelForCausalLM.from_pretrained(
    inf_model_path,
    quantization_config=quant_config,
    device_map="auto",
)

inf_tokenizer = AutoTokenizer.from_pretrained(inf_model_path)
if inf_tokenizer.pad_token is None:
    inf_tokenizer.pad_token = inf_tokenizer.eos_token


# In[ ]:
def prompt_a_model(f_prompt, f_tokenizer, f_model):
    inputs = f_tokenizer(f_prompt, return_tensors="pt").to(f_model.device)

    model_inputs = {
        "input_ids": inputs["input_ids"],
        "attention_mask": inputs.get("attention_mask")
    }

    # dynamically set the length
    input_len = inputs["input_ids"].shape[1]
    eos_token_id = f_tokenizer.convert_tokens_to_ids("<end_of_turn>")

    outputs = f_model.generate(
        # **inputs,
        **model_inputs,
        max_new_tokens=20,
        eos_token_id=eos_token_id,
        pad_token_id=eos_token_id,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,

    )
    generated_tokens = outputs[0][input_len:]
    generated_query = f_tokenizer.decode(generated_tokens, skip_special_tokens=True)
    generated_query = generated_query.split("<start_of_turn>model\n")[-1].strip()

    return generated_query


# In[ ]:
# read in trajectories created
with open(A_3_a_Gsm8k_dir + 'dpo_train_set.json', 'r') as f:
    gsm8k_data = json.load(f)


# N=8
list_of_guidance_prompts = [
    "<start_of_turn>user\n Provide another search query enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a different query enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a more descriptive search query enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a search query on a different aspect enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a search query that is more useful enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a search query that is more helpful enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a search query that is more accurate enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model",
    "<start_of_turn>Provide a search query that is more uniquely related enclosed in <search_query> </search_query><end_of_turn>\n<start_of_turn>model"
]


def log_actions_to_traj_structure(f_question, f_action_list, updated_traj):
    action_id_list = []
    #i = 0 is reserved for the original action
    i = 1
    for act in f_action_list:
        action_id_list.append({
            "id": i,
            "action": act
        })
        i += 1

    new_entry = {
        "question": f_question['question'],
        "trajectories": updated_traj,
        "action": f_question['action'],
        "evaluation": f_question['evaluation'],
        "evaluation_value": f_question['evaluation_value'],
        "actions": action_id_list
    }
    path = os.path.join(local_dir, "updated_dpo_experiment_entries.json")

    if os.path.exists(path) and os.path.getsize(path) > 0:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # if the file was a dict, wrap it in a list
        if isinstance(data, dict):
            data = [data]
    else:
        data = []

    data.append(new_entry)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def prepare_trajectory(f_traj):
    # remove last action: go to end of string and go back to the last instance of "<start_of_turn>model" and remove everything after
    last_model_index = f_traj.rfind("<start_of_turn>model")
    updated_traj = f_traj[:last_model_index + len("<start_of_turn>model")]

    return updated_traj


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


def query_the_llm(f_query, f_model_name):
    # post the query, get the response, update the trajectories
    f_response = post_llm(f_query, f_model_name)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def post_llm(f_query, f_model):
    f_messages = [
        {
            'role': 'system',
            'content': 'You are a helpful AI assistant',
        },
        {"role": "user", "content": f_query}
    ]

    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False)
    f_assistant_response = f_response['message']['content']

    return f_assistant_response


def build_filtering_query(f_question, f_conversation):
    f_query = (f"<start_of_turn>user\n"
               f"My boss asked me to answer the following question with\n the help of a search engine: {f_question}\n"
               f"This means that I might need to decompose the question into a sequence of searches before being able to answer the question. I am trying to learn how to do this more effectively, so please provide feedback on my last message. Please take a look at our conversation so far: {f_conversation}\n"
               f"When evaluating a message, please only consider the last message and do not penalize or reward me for previous messages. When evaluating an answer, please consider only whether the answer follows from the search results, and not whether you believe the answer to be correct. If there is not enough information from the search results to answer the question, you should rate any answer as \"BAD\". Pay close attention as it may initially seem like the answer is present when it is not. When evaluating a search query, please consider whether it is likely to help me answer the original question. Explain your reasoning and then answer with either \"GOOD\" or \"BAD\". <end_of_turn>\n")
    return f_query


def evaluate_response_model_check(f_response, f_model_name):
    f_prompt = (
        f"The following response was to rate an answer. Please check the response and return, the word GOOD if the rating was good, the word BAD if the rating was bad or the word NONE if it did not say. Response: {f_response}")
    f_response, f_formatted_response = query_the_llm(f_prompt, f_model_name)

    # make it all lowercase
    string_to_clean = f_response.lower()
    # remove astrix and funny punctuation - noticed some responses have ***YES*** or ***NO***
    response_to_check = re.sub(r'[\*\_\[\]\(\)\{\}]', '', string_to_clean)

    # match them as individual words with space
    f_good = bool(re.search(r'\bgood\b', response_to_check))
    f_bad = bool(re.search(r'\bbad\b', response_to_check))

    if f_good:
        return 1
    elif f_bad:
        return 0
    else:
        return -1

def prepare_trajectory(f_traj):
    # remove last action: go to end of string and go back to the last instance of "<start_of_turn>model" and remove everything after
    last_model_index = f_traj.rfind("<start_of_turn>model")
    # get the original action
    f_a_action = f_traj[last_model_index:]
    # clean it
    f_b_action = f_a_action.replace("model\n", "").replace("<eos>\n", "")
    # remove the last action
    f_updated_traj = f_traj[:last_model_index + len("<start_of_turn>model")]

    return f_updated_traj, f_b_action



# get the trajectory
total_start_time = time.time()
print("starting multiple action generations...")
i = 0
traj_prompt_dictionary = []
for question in gsm8k_data:
    list_of_actions = []
    traj = question['trajectories']
    updated_traj, sep_action = prepare_trajectory(traj)
    list_of_actions.append(sep_action)
    print("i: " + str(i))
    i += 1
    for prompt in list_of_guidance_prompts:
        updated_prompt = traj + prompt
        action = prompt_a_model(updated_prompt, inf_tokenizer, inf_model)
        list_of_actions.append(action)

    log_actions_to_traj_structure(question, list_of_actions, updated_traj)

print(f"end multiple action generations: {time.time() - total_start_time:.2f} seconds")

# In[ ]:
print("finished")
