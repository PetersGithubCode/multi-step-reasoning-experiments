# In[ ]:
import re
import matplotlib.pyplot as plt
import os

# In[ ]:
local_dir = '/home/peternicholson/Documents/A-4-b-HpQA/'
log_file_path = os.path.join(local_dir, "training_run.log")



# In[ ]:
def parse_log_file(log_file_path):

    epochs, rewards, policy_losses, value_losses, kl_divs = [], [], [], [], []
    clip_fractions, entropies, kl_coefs = [], [], []

    with open(log_file_path, "r") as f:
        for line in f:
            if "Epoch" in line:

                epoch_match = re.search(r"Epoch (\d+)", line)
                reward_match = re.search(r"Mean Reward: ([\d.-]+)", line)
                policy_loss_match = re.search(r"Policy Loss: ([\d.-]+)", line)
                value_loss_match = re.search(r"Value Loss: ([\d.-]+)", line)
                kl_div_match = re.search(r"Approx KL: ([\d.-]+)", line)
                clip_fraction_match = re.search(r"Clip Fraction: ([\d.-]+)", line)
                entropy_match = re.search(r"Entropy: ([\d.-]+)", line)
                kl_coef_match = re.search(r"KL Coef: ([\d.-]+)", line)


                if epoch_match:
                    epochs.append(int(epoch_match.group(1)))
                    # Use None as a placeholder if a metric isn't in the line
                    rewards.append(float(reward_match.group(1)) if reward_match else None)
                    policy_losses.append(float(policy_loss_match.group(1)) if policy_loss_match else None)
                    value_losses.append(float(value_loss_match.group(1)) if value_loss_match else None)
                    kl_divs.append(float(kl_div_match.group(1)) if kl_div_match else None)
                    clip_fractions.append(float(clip_fraction_match.group(1)) if clip_fraction_match else None)
                    entropies.append(float(entropy_match.group(1)) if entropy_match else None)
                    kl_coefs.append(float(kl_coef_match.group(1)) if kl_coef_match else None)


    return epochs, rewards, policy_losses, value_losses, kl_divs, clip_fractions, entropies, kl_coefs


def plot_metrics(log_file_path):
    epochs, rewards, policy_losses, value_losses, kl_divs = parse_log_file(log_file_path)

    plt.figure(figsize=(10, 6))
    plt.subplot(2, 2, 1)
    plt.plot(epochs, rewards, label="Mean Reward")
    plt.xlabel("Epoch")
    plt.ylabel("Reward")
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(epochs, policy_losses, label="Policy Loss")
    plt.plot(epochs, value_losses, label="Value Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(epochs, kl_divs, label="Approx KL")
    plt.axhline(y=0.01, color="r", linestyle="--", label="Target KL")
    plt.xlabel("Epoch")
    plt.ylabel("KL Divergence")
    plt.legend()

    plt.tight_layout()
    plt.savefig(os.path.join(local_dir, "convergence_plots.png"))
    plt.show()


def plot_and_save_metrics(log_file_path, output_dir):
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Parse metrics
    epochs, rewards, policy_losses, value_losses, kl_divs, clip_fractions, entropies, kl_coefs = parse_log_file(log_file_path)

    # Create a multi-panel figure
    plt.figure(figsize=(12, 8))

    # Plot 1: Mean Reward
    plt.subplot(2, 3, 1)
    if any(r is not None for r in rewards):
        plt.plot(epochs, rewards, label="Mean Reward", color="#1f77b4")
        plt.xlabel("Epoch")
        plt.ylabel("Mean Reward")
        plt.title("Mean Reward")
        plt.legend()
        # Save individual plot
        plt.savefig(os.path.join(output_dir, "mean_reward.png"), dpi=300, bbox_inches="tight")
        plt.clf()  # Clear current figure for individual plot

    # Plot 2: Policy and Value Loss
    plt.figure(figsize=(6, 4))
    if any(p is not None for p in policy_losses):
        plt.plot(epochs, policy_losses, label="Policy Loss", color="#ff7f0e")
    if any(v is not None for v in value_losses):
        plt.plot(epochs, value_losses, label="Value Loss", color="#2ca02c")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Policy and Value Loss")
    plt.legend()
    plt.savefig(os.path.join(output_dir, "losses.png"), dpi=300, bbox_inches="tight")
    plt.clf()

    # Plot 3: Approx KL
    plt.figure(figsize=(6, 4))
    if any(k is not None for k in kl_divs):
        plt.plot(epochs, kl_divs, label="Approx KL", color="#d62728")
        plt.axhline(y=0.01, color="black", linestyle="--", label="Target KL (0.01)")
        plt.xlabel("Epoch")
        plt.ylabel("KL Divergence")
        plt.title("Approx KL Divergence")
        plt.legend()
        plt.savefig(os.path.join(output_dir, "approx_kl.png"), dpi=300, bbox_inches="tight")
        plt.clf()

    # Plot 4: Clip Fraction
    plt.figure(figsize=(6, 4))
    if any(c is not None for c in clip_fractions):
        plt.plot(epochs, clip_fractions, label="Clip Fraction", color="#9467bd")
        plt.xlabel("Epoch")
        plt.ylabel("Clip Fraction")
        plt.title("Clip Fraction")
        plt.legend()
        plt.savefig(os.path.join(output_dir, "clip_fraction.png"), dpi=300, bbox_inches="tight")
        plt.clf()

    # Plot 5: Entropy
    plt.figure(figsize=(6, 4))
    if any(e is not None for e in entropies):
        plt.plot(epochs, entropies, label="Entropy", color="#8c564b")
        plt.xlabel("Epoch")
        plt.ylabel("Entropy")
        plt.title("Policy Entropy")
        plt.legend()
        plt.savefig(os.path.join(output_dir, "entropy.png"), dpi=300, bbox_inches="tight")
        plt.clf()

    # Plot 6: KL Coefficient
    plt.figure(figsize=(6, 4))
    if any(kc is not None for kc in kl_coefs):
        plt.plot(epochs, kl_coefs, label="KL Coefficient", color="#e377c2")
        plt.xlabel("Epoch")
        plt.ylabel("KL Coefficient")
        plt.title("KL Coefficient")
        plt.legend()
        plt.savefig(os.path.join(output_dir, "kl_coef.png"), dpi=300, bbox_inches="tight")
        plt.clf()

    # Combined figure
    plt.figure(figsize=(12, 8))
    plt.subplot(2, 3, 1)
    if any(r is not None for r in rewards):
        plt.plot(epochs, rewards, label="Mean Reward", color="#1f77b4")
        plt.xlabel("Epoch")
        plt.ylabel("Mean Reward")
        plt.title("Mean Reward")
        plt.legend()

    plt.subplot(2, 3, 2)
    if any(p is not None for p in policy_losses):
        plt.plot(epochs, policy_losses, label="Policy Loss", color="#ff7f0e")
    if any(v is not None for v in value_losses):
        plt.plot(epochs, value_losses, label="Value Loss", color="#2ca02c")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Policy and Value Loss")
    plt.legend()

    plt.subplot(2, 3, 3)
    if any(k is not None for k in kl_divs):
        plt.plot(epochs, kl_divs, label="Approx KL", color="#d62728")
        plt.axhline(y=0.01, color="black", linestyle="--", label="Target KL (0.01)")
        plt.xlabel("Epoch")
        plt.ylabel("KL Divergence")
        plt.title("Approx KL Divergence")
        plt.legend()

    plt.subplot(2, 3, 4)
    if any(c is not None for c in clip_fractions):
        plt.plot(epochs, clip_fractions, label="Clip Fraction", color="#9467bd")
        plt.xlabel("Epoch")
        plt.ylabel("Clip Fraction")
        plt.title("Clip Fraction")
        plt.legend()

    plt.subplot(2, 3, 5)
    if any(e is not None for e in entropies):
        plt.plot(epochs, entropies, label="Entropy", color="#8c564b")
        plt.xlabel("Epoch")
        plt.ylabel("Entropy")
        plt.title("Policy Entropy")
        plt.legend()

    plt.subplot(2, 3, 6)
    if any(kc is not None for kc in kl_coefs):
        plt.plot(epochs, kl_coefs, label="KL Coefficient", color="#e377c2")
        plt.xlabel("Epoch")
        plt.ylabel("KL Coefficient")
        plt.title("KL Coefficient")
        plt.legend()

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "convergence_metrics_combined.png"), dpi=300, bbox_inches="tight")
    plt.close()


# In[ ]:

output_dir = os.path.join(local_dir, "plots")
plot_and_save_metrics(log_file_path, output_dir)


