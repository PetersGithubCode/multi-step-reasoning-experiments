import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Path to the trainer state file from your last checkpoint
# Make sure to update this path to your specific checkpoint
TRAINER_STATE_PATH = "/home/peternicholson/Documents/C-4-a-Gsm8k/gemma_dpo_train/checkpoint-168/trainer_state.json"
output_dir = "/home/peternicholson/Documents/C-4-a-Gsm8k/gemma_dpo_train/checkpoint-168/plots"


def plot_dpo_metrics(log_history, output_dir=output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"output dir: {output_dir}")

    # Convert the entire log history to a single DataFrame
    df = pd.DataFrame(log_history)

    # --- Data Validation ---
    # Drop any rows that are not part of the training loop (e.g., final summary)
    if 'step' not in df.columns:
        print("Error: 'step' column not found ")
        return
    df = df.dropna(subset=['step'])  # Ensure we only have entries with a step number
    print("Log DataFrame Head")
    print(df.head())

    # --- Fig 1 - Training Loss ---
    plt.figure(figsize=(12, 6))
    plt.plot(df['step'], df['loss'], label='Training Loss', color='blue', alpha=0.8)
    plt.title('DPO Training Loss', fontsize=16)
    plt.xlabel('Training Steps')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    loss_path = os.path.join(output_dir, 'loss_plot.png')
    plt.savefig(loss_path)
    print(f"Saved loss plot to: {loss_path}")
    plt.show()

    # --- Fig 2 - Reward Metrics ---
    plt.figure(figsize=(12, 6))
    # Using the corrected keys from your log file
    plt.plot(df['step'], df['rewards/chosen'], label='Avg. Chosen Reward', marker='.', linestyle='none',
             color='darkgreen', alpha=0.6)
    plt.plot(df['step'], df['rewards/rejected'], label='Avg. Rejected Reward', marker='.', linestyle='none',
             color='darkred', alpha=0.6)
    plt.plot(df['step'], df['rewards/margins'], label='Avg. Reward Margin', color='purple', alpha=0.8)

    # Optional: Add a smoothed line to see the trend more clearly
    smoothing_window = 10  # Adjust window size as needed
    plt.plot(df['step'], df['rewards/margins'].rolling(window=smoothing_window).mean(),
             label=f'Smoothed Margin (win={smoothing_window})', color='black', linestyle='--')

    plt.title('DPO Reward Metrics During Training', fontsize=16)
    plt.xlabel('Training Steps')
    plt.ylabel('Reward Value')
    plt.legend()
    plt.grid(True)
    rewards_path = os.path.join(output_dir, 'rewards_plot.png')
    plt.savefig(rewards_path)
    print(f"Saved reward plots to: {rewards_path}")
    plt.show()

    # --- Fig 3 - Accuracy ---
    plt.figure(figsize=(12, 6))
    # Using the corrected key: 'rewards/accuracies'
    plt.plot(df['step'], df['rewards/accuracies'], label='Reward Accuracy', marker='.', linestyle='none',
             color='orange', alpha=0.6)

    # Optional: Add a smoothed line for accuracy
    plt.plot(df['step'], df['rewards/accuracies'].rolling(window=smoothing_window).mean(),
             label=f'Smoothed Accuracy (win={smoothing_window})', color='black', linestyle='--')

    plt.title('DPO Reward Accuracy During Training', fontsize=16)
    plt.xlabel('Training Steps')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1.05)
    plt.legend()
    plt.grid(True)
    accuracy_path = os.path.join(output_dir, 'accuracy_plot.png')
    plt.savefig(accuracy_path)
    print(f"Saved accuracy plot to: {accuracy_path}")
    plt.show()
if __name__ == "__main__":
    try:
        with open(TRAINER_STATE_PATH, 'r') as f:
            trainer_state = json.load(f)

        log_history = trainer_state.get("log_history")

        if log_history:
            plot_dpo_metrics(log_history)
        else:
            print("log_history not found")

    except FileNotFoundError:
        print(f"Error: The file '{TRAINER_STATE_PATH}' not found.")
    except Exception as e:
        print(f"error: {e}")
