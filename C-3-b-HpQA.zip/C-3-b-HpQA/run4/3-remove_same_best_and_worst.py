import json
import matplotlib
matplotlib.use('Agg')
import os



local_dir = '/home/peternicholson/Documents/C-3-b-HpQA/run4/'



#load in sub trajectories
with open(local_dir + "updated_best_worst_experiment_entries-2.json", "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
generated_entries = json.loads(prepared_json2)


subset = []
counter = 0
for trajectory in generated_entries:
    for item in trajectory:
        if item['best_action'] == item['worst_action']:
            counter += 1
        else:
            subset.append(item)

print("counter: " + str(counter))

path = os.path.join(local_dir, "updated_best_worst_experiment_entries-3.json")
if os.path.exists(path) and os.path.getsize(path) > 0:
    with open(path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            data = []
else:
    data = []
if not isinstance(data, list):
    data = [data]
data.append(subset)
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)