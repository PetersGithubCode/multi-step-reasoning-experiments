import json
import re

A_3_b_HpQA_dir = '/home/peternicholson/Documents/A-3-b-HpQA/'
A_5_b_HpQA_dir = '/home/peternicholson/Documents/A-5-b-HpQA/'
main_dir = '/home/peternicholson/Documents/'
local = '/home/peternicholson/Documents/C-3-b-HpQA/run4/'

#get the hotpot set
with open(main_dir + "hotpot_train_v1.1.json", "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
hotpot_set = json.loads(prepared_json2)


with open(A_3_b_HpQA_dir + '2-stage2-HpQA_filtered_kept_evaluation_log.json', 'r') as f:
    data2 = f.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
train_set = json.loads(prepared_json2)


#get the evaluation set
with open(A_5_b_HpQA_dir + "base_log_traj.json", "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
eval_set = json.loads(prepared_json2)

eval_questions = []
all_questions = [
    item.get('question')
    for item_list in eval_set
    for item in item_list
    if isinstance(item, dict)
]
print("length of train_set: " + str(len(train_set)))
#remove eval_set from the train_set and also only ones that are eval = 1 "Good" ones
subset_train_set = []
for item in train_set:
    if item["question"] not in all_questions:
        if item["evaluation_value"] == "1":
            subset_train_set.append(item)
print("length of subset_train_set: " + str(len(subset_train_set)))



#select samples that have the most trajectories
def count_model_tags(traj):
    return len(re.findall(r'<start_of_turn>model', traj))


def extract_answer_after_last_model(text):
    last_model_pos = text.rfind('<start_of_turn>model')
    if last_model_pos == -1:
        return None

    answer_start_pos = text.find('<answer>', last_model_pos)
    if answer_start_pos == -1:
        return None

    answer_end_pos = text.find('</answer>', answer_start_pos + len('<answer>'))
    if answer_end_pos == -1:
        return None

    answer_content = text[answer_start_pos + len('<answer>'):answer_end_pos].strip()
    return answer_content


sorted_sub_set = sorted(
    subset_train_set,
    key=lambda item: count_model_tags(item['trajectories']),
    reverse=True
)
#select subset that have answers
subset_with_answers = []
for item in sorted_sub_set:
    answer = extract_answer_after_last_model(item['trajectories'])
    if answer:
        item['pred_answer'] = answer
        subset_with_answers.append(item)
print("num of subset_with_answers: " + str(len(subset_with_answers)))

#get hotpot answers
hp_qa = []
for item_list in hotpot_set:
    for item in item_list:
        if isinstance(item, dict):
            q = item['question']
            a = item['answer']
            entry = {'q': q, 'a': a}
            hp_qa.append(entry)

new_subset_with_answers = []
i = 0
for item in subset_with_answers:
    print("i: " + str(i))
    i += 1
    question = item['question']
    question_exists = any(entry['q'] == question for entry in hp_qa)
    if question_exists:
        matching_entry = next(entry for entry in hp_qa if entry['q'] == question)
        item['gold_answer'] = matching_entry['a']
        new_subset_with_answers.append(item)

# Write the results to file
try:
    with open(local + "train_set_adv_dpo.json", 'a') as f:
        json.dump(new_subset_with_answers, f, indent=4)
    print(f"\nsuccessfully wrote results to '{new_subset_with_answers}'")
except IOError as e:
    print(f"\nerror writing to file: {e}")








