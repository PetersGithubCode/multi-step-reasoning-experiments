# In[ ]:
'''
* create environment: "python3 -m venv virEn"
* activate env:  "source virEn/bin/activate"
* install ollama,
* pull ollama gemma2: "ollama pull gemma2:9b"
* in virEn install ollama: "pip install ollama"
* in virEn install sentence-transformers: "pip install sentence-transformers"
* check server has nvidia gpu: "lspci | grep -i nvidia"
* check if its working: "nvidia-smi"
* install FAISS with gpu if CUDA working: "pip install faiss-gpu"
* downgrade numpy to an earlier version: "pip install "numpy<2"
* install util: "pip install psutil"

'''

# !/usr/bin/env python

# coding: utf-8


# In[ ]:
import json
import re
import ollama
import faiss
import torch
from sentence_transformers import SentenceTransformer
import os
import time
import yaml
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# In[2]:
dir_a = '/home/peternicholson/Documents/1-A-HpQA/'
base_model_path = "/home/peternicholson/Documents/gemma-2-9b-it"

# In[2]:
# Load the HotPotQA seed questions data
output_file = dir_a + "1-HpQA_seed_questions.json"
with open(output_file, 'r', encoding='utf-8') as f:
    seed_questions_hotpot = json.load(f)

print(f"Selected {len(seed_questions_hotpot)} multi-step entries loaded from {output_file}.")


# In[4]:

# FUNCTIONS A: preparation data related functions
def extract_contexts(seed_questions_hotpot):
    # get all contexts as paragraphs in a list of strings
    context_list = []
    question_list = []
    # loop the whole set
    for item in seed_questions_hotpot:
        # extract the context paragphs and join into a string "context_paragraph"
        combined_context_para = [' '.join(context[1]) for context in item['context']]
        # print(combined_context_para)
        # store the context_paragraph into the list of contexts
        context_list.append(combined_context_para)

        # extract the question also
        question_list.append(item['question'])

    return question_list, context_list


def list_of_contexts(context_group):
    list_of_concat_contexts = []
    for i in range(len(context_group)):
        for j in range(len(context_group[i])):
            context = ""
            context = context_group[i][j]
            # contexts_concatonated = contexts_concatonated + value
            list_of_concat_contexts.append(context)
        # list_of_concat_contexts.append(contexts_concatonated)

    return list_of_concat_contexts


def search_query(search_query, index, context_list_joined, the_model):
    # SEARCH QUERY: converts the query into an embedding, searches for similarity amongst the embeddings
    # encode the query into an embedding
    query_embedding = the_model.encode([search_query], convert_to_numpy=True)
    # normalize embeddings for cosine similarity
    faiss.normalize_L2(query_embedding)
    # number of nearest neighbors to retrieve
    k = 1
    # perform search
    distances, indices = index.search(query_embedding, k)

    # retrieve and format results
    results = []
    for i in range(k):
        result = {
            'text': context_list_joined[indices[0][i]],
            'similarity_score': float(distances[0][i])
        }
        results.append(result)

    # TESTING Print results
    # print(search_query)
    # for result in results:
    #    print(f"Text: {result['text']}")
    #    print(f"Similarity Score: {result['similarity_score']:.4f}\n")

    return result


def get_search_query_value(a_query):
    pattern = "<search_query>(.*?)</search_query>"
    match = re.search(pattern, a_query)
    if match:
        value = match.group(1)
        # print(value)
        return value
    else:
        print("No match found")
        return None


# In[4]:
questions_list, not_used = extract_contexts(seed_questions_hotpot)

# In[ ]:

# Load the context_list seed questions data
output_file = dir_a + "1-HpQA_context_list.json"
with open(output_file, 'r', encoding='utf-8') as f:
    context_list = json.load(f)

# In[6]:
# embedding model used
model_name = 'all-mpnet-base-v2'
# use CUDA
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

dir_b = dir_a + '/embeddings'
embeddings_file = os.path.join(dir_b, 'embeddings_float16.npy')
index_file = os.path.join(dir_b, 'faiss_index.bin')
k = 1

if not os.path.exists(index_file):
    raise FileNotFoundError(f"FAISS index not found at {index_file}")
index = faiss.read_index(index_file)
print(f"Loaded FAISS index with {index.ntotal} vectors")
model = SentenceTransformer(model_name).to(device)


# In[ ]:
# FUNCTIONS A: general functions
def has_answer_tags(f_to_check):
    # response frome the query can be a dictionary, extract string from the dict
    if isinstance(f_to_check, dict):
        f_to_check = f_to_check.get('text', '')

    f_pattern = "<answer>(.*?)</answer>"
    # re.search only works on strings
    match = re.search(f_pattern, f_to_check)
    if match:
        return True
    else:
        return False


def has_query_tags(f_to_check):
    # response frome the query can be a dictionary, extract string from the dict
    if isinstance(f_to_check, dict):
        f_to_check = f_to_check.get('text', '')

    f_pattern = "<search_query>(.*?)</search_query>"
    # re.search only works on strings
    f_match = re.search(f_pattern, f_to_check)
    if f_match:
        return True
    else:
        return False


# In[ ]:
# FUNCTIONS B: trajectories model functions
def build_seed_query(an_initial_question, num):
    a_query = (f"<start_of_turn>user\n"
               f"Please help me answer the following question in just a few words. If you think it would help to do a search, please generate a search query enclosed by <search_query> QUERY </search_query> tags.\n"
               f"Some questions may require multiple searches in order to answer, so I will allow you to make up to {num} sequential queries before answering the question.\n"
               f"Please do not repeat queries you have already issued, as this is a waste of time. I will provide search results in the following format:\n"
               f"QUERY → RESULT.\n"
               f"Once you have enough information, generate an answer enclosed by <answer>ANSWER</answer> tags. Please either issue a search query or answer the question, but not both.\n"
               f"The question is: {an_initial_question}\n"
               f"<end_of_turn>\n")
    return a_query


def post_llm(f_query, f_model):
    f_messages = [
        {"role": "user", "content": f_query}
    ]
    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False)
    f_assistant_response = f_response['message']['content']
    # print(f"Assistant: {assistant_response}")

    return f_assistant_response


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


def format_search_query_response(f_query, f_context_response):
    f_response = (f"<start_of_turn>user\n"
                  f"{f_query} → {f_context_response}.\n"
                  f"<end_of_turn>\n")
    return f_response


def format_search_query(f_context_response):
    f_response = (f"<start_of_turn>user\n"
                  f"{f_context_response}\n"
                  f"<end_of_turn>\n")
    return f_response


def prompt_a_model(f_prompt, f_tokenizer, f_model):
    inputs = f_tokenizer(f_prompt, return_tensors="pt").to(f_model.device)

    model_inputs = {
        "input_ids": inputs["input_ids"],
        "attention_mask": inputs.get("attention_mask")
    }

    # dynamically set the length
    input_len = inputs["input_ids"].shape[1]
    eos_token_id = f_tokenizer.convert_tokens_to_ids("<end_of_turn>")

    outputs = f_model.generate(
        # **inputs,
        **model_inputs,
        max_new_tokens=50,
        eos_token_id=eos_token_id,
        pad_token_id=eos_token_id,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,

    )
    generated_tokens = outputs[0][input_len:]
    f_gen_answer = f_tokenizer.decode(generated_tokens, skip_special_tokens=True)

    return f_gen_answer


def query_the_llm(f_prompt, f_model, f_tokenizer):
    f_response = prompt_a_model(f_prompt, f_tokenizer, f_model)
    # post the query, get the response, update the trajectories
    # f_response = post_llm(f_query, f_model)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def query_db(f_query, f_index, f_context_list, f_model):
    # search the query and return the response
    f_response = search_query(f_query, f_index, f_context_list, f_model)
    f_response_text = f_response['text']
    # format the response
    f_formatted_response = format_search_query_response(f_query, f_response_text)

    return f_formatted_response


# In[9]:
# data structure to hold 10,000 multi-step questions from the HotPotQA training set
# 5 trajectories per question
multi_step_questions_HotPotQA = []


# In[ ]:
# load the base model in quantized to 4bit use as inference model
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)
base_model = AutoModelForCausalLM.from_pretrained(
    base_model_path,
    quantization_config=quant_config,
    device_map="auto",
)

base_tokenizer = AutoTokenizer.from_pretrained(base_model_path)
if base_tokenizer.pad_token is None:
    base_tokenizer.pad_token = base_tokenizer.eos_token


# In[ ]:
def log_check(f_question, f_response, f_formatted_response, f_trajectories):
    new_entry = {
        "f_trajectories": f_trajectories,
        "f_response": f_response,
        "f_formatted_response": f_formatted_response,
        "f_question": f_question
    }
    with open(dir_a + "1-HpQA_log_check.json", "a", encoding="utf-8") as file:
        json.dump(new_entry, file, indent=1)


# In[ ]:
max_num = 5
# to show how long for processing
total_start_time = time.time()

# In[10]:
def generate_trajectories(f_questions_list, f_base_model, f_base_tokenizer):
    y = 0
    for question in f_questions_list:
        print(question)
        with open(dir_a + 'HpQA_question_lines.txt', 'a') as file:
            file.write(question + "\n")

        multi_step_questions_HotPotQA = []
        query_call = False
        turn = "model"
        trajectories = ""
        answered = False
        formatted_response = ""
        response = ""
        seed = True
        i = 0
        error = False
        x = 0
        already_insisted = False
        while True:
            print("i value: " + str(i))
            print("Answered: " + str(answered))
            # beginning - ask the seed question - the original prompt (pg 3)
            if seed:
                # get the question
                initial_question = question
                # build the seed query
                seed_query = build_seed_query(initial_question, max_num)
                # update history
                trajectories = seed_query
                response, formatted_response = query_the_llm(seed_query, f_base_model, f_base_tokenizer)
                # log_to_file_checking()
                log_check(question, response, formatted_response, trajectories)
                # once the model responds it's now the users turn
                turn = "user"
                # check if it has a query call
                query_call = has_query_tags(response)
                # check response for answer tag
                answered = has_answer_tags(response)
                #sometimes response had both, answered wins
                if answered:
                    query_call = False
                # update history
                trajectories = trajectories + formatted_response
                seed = False

            if turn == "user":
                if query_call:
                    if i < max_num:
                        # if its a query_call
                        # set query_call to false
                        query_call = False
                        # increment the query  call
                        i += 1
                        # get the query call value
                        print("query: " + str(response))
                        query = get_search_query_value(response)
                        formatted_response = query_db(query, index, context_list, model)
                        print("db_response: " + str(formatted_response))
                        # update the turn to the model
                        turn = "model"
                        # append returned context to the history
                        trajectories = trajectories + formatted_response
                    elif i == max_num:
                        final_query_call = f"The maximum number of sequential queries of {max_num} are used up, please generate an answer enclosed by <answer>ANSWER</answer> tags"
                        formatted_response = format_search_query(final_query_call)
                        # update the turn to the model
                        turn = "model"
                        # append returned context to the history
                        trajectories = trajectories + formatted_response
                        # set final tag to true
                        already_insisted = True
                # if it's an answer
                elif answered:
                    print("answer tag encountered")
                    # make answered false
                    answered = False
                    # append close to trajectory
                    trajectories = trajectories + "<eos>\n"
                    new_entry = {
                        "question": question,
                        "trajectories": trajectories
                    }
                    multi_step_questions_HotPotQA.append(new_entry)
                    break

                # if there is no query call and no answer then ask the model to respond properly
                else:
                    # already insisted end the question and log as an error
                    trajectories = trajectories + "<eos>\n"
                    new_entry = {
                        "question": question,
                        "trajectories": trajectories
                    }
                    multi_step_questions_HotPotQA.append(new_entry)
                    break

            if turn == "model":
                # then its a query
                # do query to llm
                response, formatted_response = query_the_llm(trajectories, f_base_model, f_base_tokenizer)
                # log_to_file_checking()
                log_check(question, response, formatted_response, trajectories)
                # once the model responds its now the users turn
                turn = "user"
                print("Response from llm: " + response)
                # check if it has a query call
                query_call = has_query_tags(response)
                # check response for answer tag
                answered = has_answer_tags(response)
                # sometimes response had both, answered wins
                if answered:
                    query_call = False
                # update history
                trajectories = trajectories + formatted_response
                #to prevent search queries going beyond the max_num
                if i == max_num:
                    # append close to trajectory
                    trajectories = trajectories + "<eos>\n"
                    new_entry = {
                        "question": question,
                        "trajectories": trajectories
                    }
                    multi_step_questions_HotPotQA.append(new_entry)
                    break

            if i == max_num + 1 and answered is False:
                error_string = "ERROR exceeded bounds"
                print("Error" + str(error_string))
                trajectories = trajectories + "<eos>\n"
                new_entry = {
                    "question": question,
                    "trajectories": trajectories
                }
                multi_step_questions_HotPotQA.append(new_entry)
                break

            if x == 50 or error is True:
                error_string = "ERROR exceeded bounds"
                print("Error" + str(error_string))
                new_entry = {
                    "question": question,
                    "trajectories": trajectories
                }
                multi_step_questions_HotPotQA.append(new_entry)
                break

            x += 1

        # update after ending the while
        with open(dir_a + "1-HpQA_trajectories_no_filtering.json", "a", encoding="utf-8") as file:
            json.dump(multi_step_questions_HotPotQA, file, indent=1)
        print("processed record: " + str(y))
        y += 1

    return


# In[10]:
generate_trajectories(questions_list, base_model, base_tokenizer)

# In[10]:
# print the end time
print(f"Total processing time: {time.time() - total_start_time:.2f} seconds")

