import ast
from typing import Any
import os
import matplotlib.pyplot as plt
import re
import numpy as np
from pathlib import Path
import json


dir = '/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/ubuntu-Runs/3/A-4-a-Gsm8k/latest-run/'
stats_file = 'training_run.log'
log_file = dir + stats_file
output_directory = dir + "charts/"


def extract_segments_interleaved(
    in_path: str,
    out_path: str,
    pairs: list[dict],
    strip_between: bool = True,
    case_sensitive: bool = True
) -> int:

    text = Path(in_path).read_text(encoding="utf-8", errors="ignore")
    source = text if case_sensitive else text.lower()

    matches = []
    for p in pairs:
        A = p["A"]
        B = p["B"]
        A_search = A if case_sensitive else A.lower()
        B_search = B if case_sensitive else B.lower()

        pos = 0
        while True:
            i = source.find(A_search, pos)
            if i == -1:
                break
            after_A = i + len(A_search)
            j = source.find(B_search, after_A)
            if j == -1:
                break

            between = text[after_A:j]
            if strip_between:
                between = between.strip()

            matches.append((i, j, A, B, between))
            pos = j + len(B_search)

    # Sort by where each A was found in the file (i)
    matches.sort(key=lambda t: t[0])

    with open(out_path, "w", encoding="utf-8") as fout:
        for _, _, A, _, between in matches:
            fout.write(f"{A}\t{between}\n")

    return len(matches)


def extract_segments_to_dict(
    in_path: str,
    pairs: list[dict],
    strip_between: bool = True,
    case_sensitive: bool = True
) -> dict:
    try:
        text = Path(in_path).read_text(encoding="utf-8", errors="ignore")
    except FileNotFoundError:
        print(f"Error: The file at {in_path} was not found.")
        return {}

    source = text if case_sensitive else text.lower()

    matches = []
    for p in pairs:
        A = p["A"]
        B = p["B"]
        A_search = A if case_sensitive else A.lower()
        B_search = B if case_sensitive else B.lower()

        pos = 0
        while True:
            i = source.find(A_search, pos)
            if i == -1:
                break
            after_A = i + len(A_search)
            j = source.find(B_search, after_A)
            if j == -1:
                break

            between = text[after_A:j]
            if strip_between:
                between = between.strip()

            matches.append((i, A, between))
            pos = j + len(B_search)

    # Sort by where each marker 'A' was found in the file
    matches.sort(key=lambda t: t[0])

    epochs_data = {}
    current_epoch_number = None

    if not pairs:
        return {}

    # The first pair in the list is assumed to be the epoch identifier
    epoch_identifier = pairs[0]["A"]

    for _, A, between in matches:
        if A == epoch_identifier:
            try:
                current_epoch_number = int(between)
                epochs_data[current_epoch_number] = {"epoch_number": current_epoch_number}
            except ValueError:
                # Handle cases where the epoch number is not a valid integer
                print(f"Warning: Could not parse epoch number from '{between}'. Skipping.")
                current_epoch_number = None
        elif current_epoch_number is not None:
            # Clean up the parameter name for use as a dictionary key
            param_name = A.strip().rstrip("': ").strip("'")

            # Attempt to convert the extracted value to a numeric type
            try:
                value = float(between)
                if value.is_integer():
                    value = int(value)
            except ValueError:
                value = between

            epochs_data[current_epoch_number][param_name] = value

    return epochs_data


def generate_charts(epochs_data: dict, out_dir: str):
    if not epochs_data:
        print("No data available to generate charts.")
        return

    # Create the output directory if it doesn't exist
    os.makedirs(out_dir, exist_ok=True)

    # Identify all unique metric names from the data
    all_metrics = set()
    for epoch in epochs_data.values():
        all_metrics.update(epoch.keys())

    # Remove the non-metric key
    if "epoch_number" in all_metrics:
        all_metrics.remove("epoch_number")

    # Get the sorted list of epoch numbers for the x-axis
    sorted_epochs = sorted(epochs_data.keys())

    # Generate a plot for each metric
    for metric in all_metrics:
        # Get the values for the current metric across all epochs
        metric_values = [epochs_data[epoch].get(metric) for epoch in sorted_epochs]

        # Filter out epochs where the metric might be missing
        valid_epochs = [epoch for epoch, value in zip(sorted_epochs, metric_values) if value is not None]
        valid_values = [value for value in metric_values if value is not None]

        if not valid_values:
            print(f"Skipping '{metric}' as no valid data points were found.")
            continue

        plt.figure(figsize=(10, 6))
        plt.plot(valid_epochs, valid_values, marker='o', linestyle='-')

        plt.title(f"Metric: {metric}")
        plt.xlabel("Epoch")
        plt.ylabel("Value")
        plt.grid(True)

        # Create a valid filename from the metric name
        safe_filename = metric.replace('/', '_').replace('\\', '_') + ".png"
        file_path = os.path.join(out_dir, safe_filename)

        try:
            plt.savefig(file_path)
            print(f"Chart for '{metric}' saved to {file_path}")
        except Exception as e:
            print(f"Error saving chart for '{metric}': {e}")

        plt.close()



# Example usage:
if __name__ == "__main__":
    pairs = [
        #{"A": "Full stats for epoch ", "B": ":"},
        #{"A": "'tokens/queries_len_mean': ", "B": ", "},  # or ", '"
        {"A": "Full stats for epoch ", "B": ":"},
        {"A": "tokens/queries_len_mean': ", "B": ", "},
        {"A": "'tokens/queries_len_std': ", "B": ", "},
        {"A": "'tokens/responses_len_mean': ", "B": ", "},
        {"A": "'tokens/responses_len_std': ", "B": ", "},
        {"A": "'ppo/loss/policy': ", "B": ", "},
        {"A": "'ppo/loss/value': ", "B": ", "},
        {"A": "'ppo/loss/total': ", "B": ", "},
        {"A": "'ppo/policy/entropy': ", "B": ", "},
        {"A": "'ppo/policy/approxkl': ", "B": ", "},
        {"A": "'ppo/policy/policykl': ", "B": ", "},
        {"A": "'ppo/policy/clipfrac': ", "B": ", "},
        {"A": "'ppo/policy/advantages_mean': ", "B": ", "},
        {"A": "'ppo/returns/mean': ", "B": ", "},
        {"A": "'ppo/val/vpred': ", "B": ", "},
        {"A": "'ppo/val/error': ", "B": ", "},
        {"A": "'ppo/val/clipfrac': ", "B": ", "},
        {"A": "'ppo/val/mean': ", "B": ", "},
        {"A": "'ppo/learning_rate': ", "B": ", "},
        {"A": "'time/ppo/forward_pass': ", "B": ", "},
        {"A": "'time/ppo/compute_rewards': ", "B": ", "},
        {"A": "'time/ppo/compute_advantages': ", "B": ", "},
        {"A": "'time/ppo/optimize_step': ", "B": ", "},
        {"A": "'time/ppo/calc_stats': ", "B": ", "},
        {"A": "'time/ppo/total': ", "B": ", "},
    ]

    # The directory to save files, not used in the new function but kept for context
    dir = "./"
    if not os.path.exists(dir):
        os.makedirs(dir)

    data = extract_segments_to_dict(
        in_path=log_file,
        pairs=pairs,
        strip_between=True,
        case_sensitive=True
    )

    if data:
        generate_charts(epochs_data=data, out_dir=output_directory)

    print(json.dumps(data, indent=4))


    data = extract_segments_interleaved(
        in_path=log_file,
        out_path=dir + "extracted_interleaved.txt",
        pairs=pairs,
        strip_between=True,
        case_sensitive=True
    )

    print(f"Wrote {data} matches to extracted_interleaved.txt")