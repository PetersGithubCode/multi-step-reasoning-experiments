# In[ ]:
import torch
from torch.utils.data import DataLoader
from trl.core import LengthSampler
from trl import AutoModelForCausalLMWithValueHead, PPOConfig, PPOTrainer
from transformers import BitsAndBytesConfig, AutoModelForCausalLM, AutoTokenizer
from tqdm import tqdm
from peft import LoraConfig, get_peft_model, PeftModel
from accelerate import Accelerator
from datasets import load_from_disk, Dataset
import time
import bitsandbytes.optim as bnb_optim
import os
import random  # Imported for simulating judge model's response
from huggingface_hub import login, snapshot_download
import glob
import logging
import sys

# In[ ]:
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
torch.cuda.empty_cache()

# In[ ]:
local_dir = '/home/peternicholson/Documents/A-4-a-Gsm8k/'

# In[ ]:
local_model_path = "/home/peternicholson/Documents/gemma-2-9b-it"

# In[ ]:
# add logging file
log_file_path = os.path.join(local_dir, "training_run.log")
# out put of PPO process logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] - %(message)s",
    handlers=[
        logging.FileHandler(log_file_path),
        logging.StreamHandler(sys.stdout)
    ]
)

logging.captureWarnings(True)
logger = logging.getLogger(__name__)
logger.info("Starting training run...")


# In[ ]:
# Function to log convergence metrics
def preprocess_metrics(stats, rewards, logger=None):
    if logger is None:
        import logging
        logger = logging.getLogger(__name__)
    processed_stats = {}
    metric_keys = [
        "ppo/loss/policy",
        "ppo/loss/value",
        "ppo/policy/approxkl",
        "ppo/policy/clipfrac",
        "ppo/policy/entropy",
        "ppo/policy/kl_coef"
    ]
    for key in metric_keys:
        value = stats.get(key, "N/A")
        try:
            # Attempt to cast to float
            processed_stats[key] = float(value)
        except (TypeError, ValueError):
            # Log warning if conversion fails
            if value != "N/A":
                logger.warning(f"Invalid value for {key}: {value}, setting to 'N/A'")
            processed_stats[key] = "N/A"

    processed_rewards = []
    if rewards:
        for reward in rewards:
            try:
                processed_rewards.append(float(reward))
            except (TypeError, ValueError):
                logger.warning(f"Invalid reward value: {reward}, skipping")
        if not processed_rewards:
            logger.warning("All rewards were invalid, returning empty list")

    return processed_stats, processed_rewards


def log_convergence_metrics(epoch, stats, rewards, logger):
    def format_metric(value, spec):
        """Formats a metric if it's a number, otherwise returns 'N/A'."""
        if isinstance(value, (int, float)):
            # If it's a number, apply the desired formatting.
            return f"{value:{spec}}"
        # Otherwise, return the safe fallback string.
        return "N/A"

    # Extract metrics (TRL-specific keys)
    policy_loss = stats.get("ppo/loss/policy")
    value_loss = stats.get("ppo/loss/value")
    approx_kl = stats.get("ppo/policy/approxkl")
    clip_fraction = stats.get("ppo/policy/clipfrac")
    entropy = stats.get("ppo/policy/entropy")
    kl_coef = stats.get("ppo/policy/kl_coef")
    mean_reward = sum(rewards) / len(rewards) if rewards else None

    # log message
    logger.info(
        f"Epoch {epoch + 1}: "
        f"Policy Loss: {format_metric(policy_loss, '.4f')}, "
        f"Value Loss: {format_metric(value_loss, '.4f')}, "
        f"Approx KL: {format_metric(approx_kl, '.4f')}, "
        f"Clip Fraction: {format_metric(clip_fraction, '.4f')}, "
        f"Entropy: {format_metric(entropy, '.4f')}, "
        f"KL Coef: {format_metric(kl_coef, '.4f')}, "
        f"Mean Reward: {format_metric(mean_reward, '.2f')}"
    )

    # Optional: Warn if KL divergence is too high
    if isinstance(approx_kl, float) and approx_kl > 0.02:
        logger.warning(f"High KL divergence: {approx_kl:.4f}, consider adjusting learning rate or KL coef")


def find_latest_checkpoint(directory):
    checkpoint_dirs = glob.glob(os.path.join(directory, "ppo_checkpoint_batch_*"))
    if not checkpoint_dirs:
        print("No checkpoint found, starting from scratch.")
        return None, 0

    latest_dir = max(checkpoint_dirs, key=lambda d: int(d.split('_')[-1]))
    start_epoch = int(latest_dir.split('_')[-1])
    print(f"Found latest checkpoint to resume from: {latest_dir}")
    return latest_dir, start_epoch


resume_from_checkpoint, start_epoch = find_latest_checkpoint(local_dir)

# In[ ]:
print(f"Loading tokenizer from local path: {local_model_path}")
tokenizer = AutoTokenizer.from_pretrained(local_model_path)

print(f"Loading model from local path: {local_model_path}")


# In[ ]:
# Experiencing memory issues so function created to check
def print_gpu_memory(step_description=""):
    if torch.cuda.is_available():
        allocated_memory = torch.cuda.memory_allocated() / 1024 ** 3
        reserved_memory = torch.cuda.memory_reserved() / 1024 ** 3
        print(f"{step_description} - GPU Memory Allocated: {allocated_memory:.2f} GB")
        print(f"{step_description} - GPU Memory Reserved: {reserved_memory:.2f} GB")
    else:
        print(f"{step_description} - CUDA is not available. No GPU memory information.")


# In[ ]:
print("Before loading base model:")
print_gpu_memory()

# In[ ]:
# Configuration for the Policy Model
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
)
# During the training process checkpoints will be saved. These conditions allow to load from the check rather
# than starting the whole training run again
if not resume_from_checkpoint:
    # Base model with quantization
    base_model_rl = AutoModelForCausalLM.from_pretrained(
        local_model_path,
        # device_map="auto",
        quantization_config=quant_config
    )
    print("After loading base model:")
    print_gpu_memory()

    # Apply LoRA configuration using PEFT
    peft_model_base_model_rl = get_peft_model(base_model_rl, lora_config)
    print("\nAfter applying LoRA:")
    print_gpu_memory()

    # Wrap the PEFT model with TRL's value head. For the PPO trainer.
    base_model_rl = AutoModelForCausalLMWithValueHead.from_pretrained(peft_model_base_model_rl)
    print("\nAfter wrapping with value head:")
    print_gpu_memory()

else:
    print(f"Loading model and adapter from checkpoint: {resume_from_checkpoint}")
    # TRL ValueHead model loaded directly from a PEFT checkpoint
    base_model_rl = AutoModelForCausalLMWithValueHead.from_pretrained(
        resume_from_checkpoint,
        quantization_config=quant_config
    )

base_model_rl.gradient_checkpointing_enable()
print("Model initialization complete.")
print_gpu_memory("After final model setup")

# In[ ]:
tokenizer_path = resume_from_checkpoint if resume_from_checkpoint else local_model_path
print(f"Loading tokenizer from: {tokenizer_path}")
rl_tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)

# fix eos issues for the policy model's tokenizer
if getattr(rl_tokenizer, "pad_token", None) is None:
    rl_tokenizer.pad_token = rl_tokenizer.eos_token
    rl_tokenizer.pad_token_id = rl_tokenizer.eos_token_id

# In[ ]:
ppo_data_set = load_from_disk("/home/peternicholson/Documents/A-3-a-Gsm8k/" + "ppo_dataset")
train_dataset = ppo_data_set


# In[ ]:

def build_dataset(tokenizer, train_dataset):
    original_columns = train_dataset.column_names
    num_proc = min(24, os.cpu_count() or 4)

    def preprocess_function(examples):
        # This function coverts the following values incl 'evaluation_value'
        new_examples = {
            "query": [],
            "input_ids": [],
            "evaluation_value": [],
        }

        for i in range(len(examples["question"])):
            trajectory_text = examples.get("trajectories", [None] * len(examples["question"]))[i]
            query = trajectory_text or examples["question"][i]

            tokenized = tokenizer(query, truncation=True, max_length=512, padding=False)

            new_examples["query"].append(query)
            new_examples["input_ids"].append(tokenized["input_ids"])

            # Convert the evaluation value from string ("1" or "0") to float
            eval_val_str = examples["evaluation_value"][i]

            # During evaluation when the eval model failed to come back with correct evaluations they
            # the evaluation value was stored as -1, we need to deal with these examples.
            # make sure the reward can only be 1 or -1
            reward_val = float(eval_val_str)
            if reward_val != 1.0:
                reward_val = -1.0

            new_examples["evaluation_value"].append(float(reward_val))

        return new_examples

    columns_to_remove = [col for col in original_columns if col not in ["evaluation_value"]]

    ds = train_dataset.map(
        preprocess_function,
        batched=True,
        num_proc=num_proc,

    )

    ds = ds.select_columns(["input_ids", "query", "evaluation_value"])

    # filter if greater than 512 tokens
    # turned off filter
    ds = ds.filter(lambda x: len(x["input_ids"]) < 512, batched=False)
    ds.set_format(type="torch")  # Let TRL handle column formatting

    return ds


# In[ ]:
# dataset = build_dataset(rl_tokenizer)
dataset = build_dataset(rl_tokenizer, train_dataset=train_dataset)


# In[ ]:
#config for PPO
#generation_kwargs
max_new_tokens= 64
temperature=1.2
top_k=1
min_length=3
top_p=1.0
do_sample=True

#PPOConfig
#total_steps = (num_samples / batch_size)450 * 4 = 1800
steps=450
learning_rate=1.5e-5
batch_size=4
mini_batch_size=1
gradient_accumulation_steps=4
ppo_epochs=2
target_kl=0.01
init_kl_coef=0.5
adap_kl_ctrl=True
vf_coef=0.5


# In[ ]:
print("Sanity Check: Inspecting the processed dataset")
print(f"Columns in the final dataset: {dataset.column_names}")


# In[ ]:
def collator(data):
    # return dict((key, [d[key] for d in data]) for key in data[0])
    return {key: [d[key] for d in data] for key in data[0]}


# In[ ]:
config = PPOConfig(
    steps=steps,
    model_name=local_model_path,
    learning_rate=learning_rate,
    batch_size=batch_size,
    mini_batch_size=mini_batch_size,
    gradient_accumulation_steps=gradient_accumulation_steps,
    optimize_cuda_cache=True,
    early_stopping=True,
    ppo_epochs=ppo_epochs,
    target_kl=target_kl,
    init_kl_coef=init_kl_coef,
    adap_kl_ctrl=adap_kl_ctrl,
    vf_coef=vf_coef
)

# In[ ]:
optimizer = bnb_optim.PagedAdamW8bit(
    filter(lambda p: p.requires_grad, base_model_rl.parameters()),
    lr=config.learning_rate
)

# In[ ]:
# Initialize PPOTrainer
ppo_trainer = PPOTrainer(
    config=config,
    model=base_model_rl,
    ref_model=None,
    tokenizer=rl_tokenizer,
    dataset=None,
    data_collator=collator,
    optimizer=optimizer
)

dataloader = DataLoader(
    # dataset,
    # needed as full batch beyond processing amount
    dataset,
    batch_size=config.batch_size,
    collate_fn=collator,
    # avoid getting the Value error: batch size does not match number of examples
    drop_last=True
)

# In[ ]:
device = ppo_trainer.accelerator.device
# if ppo_trainer.accelerator.num_processes == 1:
#    device = 0

# In[ ]:

generation_kwargs = {
    "max_new_tokens": max_new_tokens,
    # probability distribution to increase randomness
    "temperature": temperature,
    # greater variance
    "top_k": top_k,
    # at least some response
    "min_length": min_length,
    "top_p": top_p,
    "do_sample": True,
    "pad_token_id": rl_tokenizer.pad_token_id,
    "eos_token_id": rl_tokenizer.eos_token_id,
}

# In[ ]:
num_batches = len(dataloader)
print(f"The DataLoader will produce {num_batches} batches per epoch.")

# In[ ]:
output_min_length = 32
output_max_length = 128
output_length_sampler = LengthSampler(output_min_length, output_max_length)

# In[ ]:
print("PPO training start")
total_start_time = time.time()

dataloader = ppo_trainer.accelerator.prepare(dataloader)

# In[ ]:
# this will load the state of the model from the checkpoint
if resume_from_checkpoint:
    optimizer_checkpoint_path = os.path.join(resume_from_checkpoint, "optimizer.pt")
    if os.path.exists(optimizer_checkpoint_path):
        print(f"Loading optimizer state from: {optimizer_checkpoint_path}")
        # Move optimizer state to the correct device
        optimizer_state_dict = torch.load(optimizer_checkpoint_path, map_location="cpu")
        optimizer.load_state_dict(optimizer_state_dict)
        print("Successfully loaded optimizer state dict into local optimizer.")
    else:
        print("Warning: Checkpoint found, but optimizer state not found. Starting with a fresh optimizer.")

# In[ ]:
# for epoch, batch in tqdm(enumerate(ppo_trainer.dataloader)):
# for epoch, batch in tqdm(enumerate(dataloader)):
for epoch, batch in tqdm(enumerate(dataloader), total=len(dataloader)):
    # Skip completed batches
    if epoch < start_epoch:
        continue

    print_gpu_memory(f"Epoch {epoch} start")

    if epoch == 0:
        print(f"Keys in the first batch from our custom DataLoader: {list(batch.keys())}")

    # Note: `batch['input_ids']` from our collator is a list of tensors
    question_tensors = batch["input_ids"]
    # question_tensors = [t.to(device) for t in batch["input_ids"]]

    # Generate responses for the batch
    response_tensors = ppo_trainer.generate(
        question_tensors,
        return_prompt=False,
        length_sampler=output_length_sampler,
        **generation_kwargs,
    )

    # The response texts are decoded for the judge model
    batch["response"] = rl_tokenizer.batch_decode(response_tensors, skip_special_tokens=True)

    rewards = batch["evaluation_value"]

    torch.cuda.empty_cache()

    # PPO step - learn from the batch: updates model weights using queries, responses, and rewards
    stats = ppo_trainer.step(question_tensors, response_tensors, rewards)

    # START: newly added to see where kl divergence is negative what the tokens might be
    if 'objective/kl' in stats and stats['objective/kl'] < 0:
        print(f"--- DETECTED NEGATIVE KL AT STEP {epoch} ---")
        print(f"KL Value: {stats['objective/kl']}")

        # Decode and print the prompts and responses that caused it
        prompts = rl_tokenizer.batch_decode(question_tensors, skip_special_tokens=True)
        responses = rl_tokenizer.batch_decode(response_tensors, skip_special_tokens=True)

        for i in range(len(prompts)):
            print(f"  Prompt {i}: {prompts[i][:200]}...")  # Print first 200 chars
            print(f"  Response {i}: {responses[i]}")

    ppo_trainer.log_stats(stats, batch, rewards)
    # log full stats
    logger.info(f"Full stats for epoch {epoch + 1}: {stats}")

    # additional logging to attempt to log convergence
    # Log stats
    log_convergence_metrics(epoch, stats, rewards, logger)

    # Save every 10 batches
    if (epoch + 1) % 10 == 0:
        print(f"Saving checkpoint at batch {epoch + 1}")
        save_path = f"{local_dir}ppo_checkpoint_batch_{epoch + 1}"
        os.makedirs(save_path, exist_ok=True)
        ppo_trainer.model.save_pretrained(save_path)
        ppo_trainer.tokenizer.save_pretrained(save_path)

print(f"PPO training finished in {time.time() - total_start_time:.2f} seconds")

# In[ ]:
if ppo_trainer.accelerator.is_main_process:
    print("saving final...")
    save_path_final = local_dir + "ppo_offline_rl_final_adapter"
    os.makedirs(save_path_final, exist_ok=True)
    ppo_trainer.save_pretrained(save_path_final)

# In[ ]:
print("finished")

# In[ ]:
