# In[ ]:
import ollama
import json
import torch
from transformers import BitsAndBytesConfig, AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from tqdm import tqdm
import re
import os
from datetime import datetime
from peft import PeftModel
import gc

# In[ ]:
local_path = '/home/peternicholson/Documents/A-5-b-HpQA/'
main_dir = '/home/peternicholson/Documents/'
model_judge = "gemma3:27b"
local_model_path = "/home/peternicholson/Documents/gemma-2-9b"
trained_ppo_model_path = "/home/peternicholson/Documents/A-4-b-HpQA/ppo_offline_rl_final_adapter"
trained_dpo_model_path = "/home/peternicholson/Documents/C-4-b-HpQA/gemma_dpo_train"
trained_dpo_2_model_path = "/home/peternicholson/Documents/C-4-b-HpQA/run4/gemma_dpo_train"


# In[ ]:
'''
A PROMPT and EXAMPLES pg 15  - Wu et al. (2024)

Prompts of QA
--------------
Prompt: You are a QA test machine, you need to answer the [Question] from given the [Context], and you
only need to come out with the correct answer without other words. Let’s think step by step, and please
output the answer to the [Question] in the format of: {Final Answer: String}.
[QUESTION] The given question.
[CONTEXT] The given passage.


Prompts of Partial Match Evaluation
--------------
Prompt: You are an Answer evaluator, you need to measure the semantic similarity between [Generated
Answer] and [Gold Answer], and give the score, 1 means equal, 0 means not. Some answers may have
abbreviations or alias, for example, Lionel Messi is equal to Messi, Donald Trump is equal to Trump.
Please only output the score 1 or 0 without any other words.
[Generated Answer] The LLM generated answer.
[Gold Answer] The ground truth.

'''


# In[ ]:

def create_prompt_pm_eval(f_gen_answer, f_gold_answer):
    f_prompt_pm_eval = (
        f"You are an Answer evaluator, you need to measure the semantic similarity between [{f_gen_answer}]\n"
        f"and [{f_gold_answer}], and give the score, 1 means equal, 0 means not. Some answers may have\n"
        f"abbreviations or alias, for example, Lionel Messi is equal to Messi, Donald Trump is equal to Trump.\n"
        f"Please only output the score 1 or 0 without any other words.\n"
    )
    return f_prompt_pm_eval


def process_outcome(f_response):
    if "1" in f_response:
        return True
    if "0" in f_response:
        return False
    else:
        return -1


def post_ollama_eval_model(f_query, f_model):
    f_messages = [
        {"role": "user", "content": f_query}
    ]
    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False)
    f_assistant_response = f_response['message']['content']
    # print(f"Assistant: {assistant_response}")

    return f_assistant_response


def query_the_judge_llm(f_query, f_model_name):
    # post the query, get the response, update the trajectories
    f_response = post_ollama_eval_model(f_query, f_model_name)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def query_local_llm(f_query, f_model, f_tokenzier):
    # post the query, get the response, update the trajectories
    f_response = post_llm(f_query, f_model, f_tokenzier)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def post_llm(f_prompt, f_model, f_tokenzier):
    inputs = f_tokenzier(f_prompt, return_tensors="pt").to(f_model.device)
    # dynamically set the length
    input_len = inputs["input_ids"].shape[1]
    eos_token_id = f_tokenzier.convert_tokens_to_ids("<end_of_turn>")
    outputs = f_model.generate(
        **inputs,
        max_new_tokens=50,
        eos_token_id=eos_token_id,
        pad_token_id=eos_token_id,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,

    )
    generated_tokens = outputs[0][input_len:]
    f_assistant_response = f_tokenzier.decode(generated_tokens, skip_special_tokens=True)

    return f_assistant_response


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


# In[ ]:
def evaluate_with_inference_model(list_of_entries, f_ollama_model_name, f_file_to_save):
    f_counter = 0
    for entry in list_of_entries:
        id = entry['id']
        question = entry['question']
        context_data = entry['context']
        golden_answer = entry['golden_answer']
        model_prompt = entry['model_prompt']
        model_gen_answer = entry['gen_model_answer']
        model_answer_extracted = entry['model_answer_extracted']
        model_answer_extracted_2 = entry['model_answer_extracted_via_judge']

        # query evaluation model for Base
        prompt_model_eval = create_prompt_pm_eval(model_answer_extracted, golden_answer)
        response_model_updated, form_response_model_updated = query_the_judge_llm(prompt_model_eval,
                                                                                  f_ollama_model_name)
        model_response = str(form_response_model_updated)
        model_response_outcome = process_outcome(model_response)
        if model_response_outcome:
            f_counter += 1

        prompt_model_eval_2 = create_prompt_pm_eval(model_answer_extracted_2, golden_answer)
        response_model_updated_2, form_response_model_updated_2 = query_the_judge_llm(prompt_model_eval,
                                                                                  f_ollama_model_name)
        model_response_2 = str(form_response_model_updated_2)
        model_response_outcome_2 = process_outcome(model_response_2)
        if model_response_outcome_2:
            f_counter += 1


        f_entry = {
            'id': id,
            'question': question,
            'context': context_data,
            'golden_answer': golden_answer,
            'model_prompt': model_prompt,
            'model_gen_answer': model_gen_answer,
            'model_answer_extracted': model_answer_extracted,
            'model_evaluation': model_response,
            'model_outcome': model_response_outcome,
            'model_outcome_2': model_response_outcome_2

        }
        with open(f_file_to_save, 'a', encoding="utf-8") as f_file:
            json.dump(f_entry, f_file, indent=1)

    return f_counter


def join_contexts(f_context_data):
    f_formatted_data = []
    for title, sentences in f_context_data:
        content = " ".join(sentences)
        f_formatted_data.append(f"Title: {title}\n{content}")

    return "\n".join(f_formatted_data)


def create_prompt_qa(f_question, f_context):
    f_prompt_qa = (
        f"You are a QA test machine, you need to answer the question: [{f_question}] from given the context: [{f_context}],\n"
        f"and you only need to come out with the correct answer without other words. Let’s think step by step,\n"
        f"and please output the answer to the [{f_question}] in the format of: {{Final Answer: String}}."
    )
    return f_prompt_qa



def extract_final_response(f_trajectory):
    answer_value = None
    # start at the end of trajectory, structure will be <eos><end_of_turn><answer></answer><start_of_turn>model
    # remove \n lines
    f_trajectory = f_trajectory.replace('\n', '')
    # get start position of {Final Answer:
    start_marker = f_trajectory.rfind('{Final Answer:')
    # not found answer marker
    if start_marker != -1:
        start_marker += 14
        end_marker = f_trajectory.find('}', start_marker)
        if end_marker != -1:
            answer_value = f_trajectory[start_marker:end_marker].strip()

    return answer_value



def extract_final_response_2(f_answer_long, f_golden_answer, f_ollama_model_name):
    f_prompt_qa = (
        f"From the following string please look for the answer in the string and return only the answer from the string, "
        f"the string is: {f_answer_long}"
    )
    f_response, f_formatted_response = query_the_judge_llm(f_prompt_qa, f_ollama_model_name)

    return f_response




def process_prompts_local(list_of_entries, f_model, f_tokenizer):
    i = 0
    new_list = []
    print("length of entries:" + str(len(list_of_entries)))

    for entry in list_of_entries:
        print("i: " + str(i))
        i += 1

        id = entry['_id']
        context_data = entry['context']
        question = entry['question']
        golden_answer = entry['answer']
        joined_context = join_contexts(context_data)
        prompt_qa = create_prompt_qa(question, joined_context)
        gen_model_answer, form_gen_model_answer = query_local_llm(prompt_qa, f_model, f_tokenizer)
        model_answer = extract_final_response(form_gen_model_answer)
        model_answer_2 = extract_final_response_2(gen_model_answer, golden_answer, model_judge)

        model_answer = str(model_answer)

        new_list.append({
            'id': id,
            'question': question,
            'context': context_data,
            'golden_answer': golden_answer,
            'model_prompt': prompt_qa,
            'gen_model_answer': form_gen_model_answer,
            'model_answer_extracted': model_answer,
            'model_answer_extracted_via_judge': model_answer_2
        })

    return new_list


# In[ ]:


# load the hotpot data
with open(
        main_dir + 'hotpot_train_v1.1.json',
        'r') as f:
    hotpot_data = json.load(f)

# extract only the ids from the Swirl paper used in evaluations
with open(main_dir + "HpQA-eval-ids.txt", "r", encoding="utf-8") as f:
    id_set = {line.strip() for line in f if line.strip()}

filtered_entries = [entry for entry in hotpot_data if entry.get('_id') in id_set]
# for testing
# filtered_entries = filtered_entries[:1000]


print("process base prompts...")

# set up base model
print(f"Loading tokenizer from local path: {local_model_path}")
tokenizer = AutoTokenizer.from_pretrained(local_model_path)
print(f"Loading model from local path: {local_model_path}")

quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)

base_model = AutoModelForCausalLM.from_pretrained(
    local_model_path,
    quantization_config=quant_config
)

print("Base Model initialization complete.")
base_model.eval()

# In[ ]:
# evalute base line
# generate base prompts
entries_base_prompts = process_prompts_local(filtered_entries, base_model, tokenizer)
# evaluate base prompts and save to base file
results_counter = evaluate_with_inference_model(entries_base_prompts, model_judge, local_path + "base_evaluations.json")
print("base count: " + str(results_counter))

# evalute PPO
# generate trained ppo trajectories
print("Applying adapter to trained ppo model...")
trained_ppo_model = PeftModel.from_pretrained(base_model, trained_ppo_model_path)
print("Loading tokenizer...")
saved_ppo_tokenizer = AutoTokenizer.from_pretrained(trained_ppo_model_path)

entries_ppo_prompts = process_prompts_local(filtered_entries, trained_ppo_model, saved_ppo_tokenizer)
results_counter = evaluate_with_inference_model(entries_ppo_prompts, model_judge, local_path + "ppo_evaluations.json")
print("ppo count: " + str(results_counter))

# clean up memory to avoid running out
print("\nClearing ppo model from memory...")
del trained_ppo_model
del saved_ppo_tokenizer
gc.collect()
torch.cuda.empty_cache()
print("Memory cleared.\n")

# evalute DPO
# generate trained ppo trajectories
print("Applying adapter to trained dpo model...")
trained_dpo_model = PeftModel.from_pretrained(base_model, trained_dpo_model_path)
print("Loading tokenizer...")
saved_dpo_tokenizer = AutoTokenizer.from_pretrained(trained_dpo_model_path)

entries_dpo_prompts = process_prompts_local(filtered_entries, trained_dpo_model, saved_dpo_tokenizer)
results_counter = evaluate_with_inference_model(entries_dpo_prompts, model_judge, local_path + "dpo_evaluations.json")
print("dpo count: " + str(results_counter))


# clean up memory to avoid running out
print("\nClearing dpo model from memory...")
del trained_dpo_model
del saved_dpo_tokenizer
gc.collect()
torch.cuda.empty_cache()
print("Memory cleared.\n")


# evalute DPO 2
# generate trained ppo trajectories
print("Applying adapter to trained dpo 2 model...")
trained_dpo_2_model = PeftModel.from_pretrained(base_model, trained_dpo_2_model_path)
print("Loading tokenizer...")
saved_dpo_2_tokenizer = AutoTokenizer.from_pretrained(trained_dpo_2_model_path)

entries_dpo_prompts = process_prompts_local(filtered_entries, trained_dpo_2_model, saved_dpo_2_tokenizer)
results_counter = evaluate_with_inference_model(entries_dpo_prompts, model_judge, local_path + "dpo_2_evaluations.json")
print("dpo count: " + str(results_counter))

# In[ ]:
print("finished")
