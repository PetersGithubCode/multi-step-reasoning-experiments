import json
from collections import Counter

dir = "/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/ubuntu-Runs/3/A-5-b-HpQA/run3/run-3-1000-random-samples"
file_open_dpo = dir + "/dpo_log_traj.json"
file_open_base = dir + "/base_log_traj.json"
file_open_ppo = dir + "/ppo_log_traj.json"

file_open_dpo_2 = "/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/ubuntu-Runs/3/A-5-b-HpQA/run4/dpo_log_traj.json"


def extract_from_pattern(text):
    # Search from the end (right to left)
    pattern = "start_of_turn>model"
    start_pos = text.rfind(pattern)  # rfind searches from the end

    if start_pos != -1:
        return text[start_pos:]  # Extract from pattern position to end
    else:
        return None

#dpo2
with open(file_open_dpo_2, 'r', encoding='utf-8') as f:
    data_dpo_2 = json.load(f)

no_answer_dpo_2 = 0
for items in data_dpo_2:
    if items["answer"] is None:
        no_answer_dpo_2 += 1

counter_dpo_2 = 0
for items in data_dpo_2:
    if 0 == len(items["contexts_from_hops"]):
        counter_dpo_2 += 1

hop_len = []
for items in data_dpo_2:
    hop_len.append(len(items['contexts_from_hops']))

counts = Counter(hop_len)
result = [counts.get(i, 0) for i in range(11)]
#print(result)


#dpo
with open(file_open_dpo, 'r', encoding='utf-8') as f:
    data_dpo = json.load(f)

#baseline
with open(file_open_base, 'r', encoding='utf-8') as f:
    data_base = json.load(f)

#ppoline
with open(file_open_ppo, 'r', encoding='utf-8') as f:
    data_ppo = json.load(f)

single_hop = []
for items in data_dpo:
    if 1 == len(items["contexts_from_hops"]):
        single_hop.append(items)

hop_len = []
for items in data_ppo:
    hop_len.append(len(items['contexts_from_hops']))

counts = Counter(hop_len)
result = [counts.get(i, 0) for i in range(11)]
print(result)

just_traj = []
just_answers = []
for items in single_hop:
    just_traj.append(items["trajectory"])
    just_answers.append(items["golden_answer"])

just_last_model_action = []
for item in just_traj:
    model_action = extract_from_pattern(item)
    just_last_model_action.append(model_action)


# 0 hops
counter_dpo = 0
for items in data_dpo:
    if 0 == len(items["contexts_from_hops"]):
        counter_dpo += 1

hop_len = []
for items in data_ppo:
    hop_len.append(len(items['contexts_from_hops']))

counts = Counter(hop_len)
result = [counts.get(i, 0) for i in range(11)]
print(result)

counter_base = 0
for items in data_base:
    if 0 == len(items["contexts_from_hops"]):
        counter_base += 1


counter_ppo = 0
for items in data_ppo:
    if 0 == len(items["contexts_from_hops"]):
        counter_ppo += 1

#no answer
no_answer_dpo = 0
for items in data_dpo:
    if items["answer"] is None:
        no_answer_dpo += 1



no_answer_base = 0
for items in data_base:
    if items["answer"] is None:
        no_answer_base += 1

no_answer_ppo = 0
for items in data_ppo:
    if items["answer"] is None:
        no_answer_ppo += 1

# >7 hops
counter_dpo = 0
for items in data_dpo:
    if 0 == len(items["contexts_from_hops"]):
        counter_dpo += 1

counter_base = 0
for items in data_base:
    if 0 == len(items["contexts_from_hops"]):
        counter_base += 1

counter_ppo = 0
for items in data_ppo:
    if 0 == len(items["contexts_from_hops"]):
        counter_ppo += 1

print("yes")

