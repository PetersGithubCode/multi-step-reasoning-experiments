import json
import matplotlib.pyplot as plt
from transformers import AutoTokenizer
import matplotlib
matplotlib.use('Agg')
import os
import time


local = '/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/ubuntu-Runs/3/A-3-a-Gsm8k/'
local_model_path = "/Users/peternicholson/PycharmProjects/pythonProject/thesis-semester2-2025/phycharmFiles/LLM-mlx-gemma2-9b-it-4bit"
previous_dpo_path = local

def get_token_lengths(list_of_strings: list[str], model_path: str) -> list[int]:

    try:
        # Load the tokenizer from the specified local path
        tokenizer = AutoTokenizer.from_pretrained(model_path)
    except OSError as e:
        print(f"Error: Could not load tokenizer from '{model_path}'.")
        print("Please ensure the path is correct and contains the tokenizer files.")
        raise e

    # Use a list comprehension for a clean and efficient way to get token counts
    token_lengths = [
        tokenizer(text, return_tensors="pt")["input_ids"].shape[1]
        for text in list_of_strings
    ]

    return token_lengths

print("\nStep 2: Loading tokenizer...")
tokenizer = None
try:
    start_time = time.time()
    tokenizer = AutoTokenizer.from_pretrained(local_model_path)
    end_time = time.time()
    print(f"--- Tokenizer loaded successfully in {end_time - start_time:.2f} seconds. ---")
except Exception as e:
    print("\n--- ERROR ---")
    print(f"An error occurred while trying to load the tokenizer from: '{local_model_path}'")
    print(f"The specific error was: {e}")
    exit()

#load in sub trajectories
with open(local + "dpo_train_set.json", "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
generated_entries = json.loads(prepared_json2)

#chart the token lengths for the evaluations with "0"
tokens_eval_0 = []
for trajectory in generated_entries:
    for item in trajectory:
        tokens_eval_0.append(item['trajectories'])

lengths_b = get_token_lengths(tokens_eval_0, local_model_path)

# Create a histogram Distribution_of_Token_Lengths
plt.figure(figsize=(8, 6))  # Set figure size
plt.hist(lengths_b, bins=30, range=(0, 1500), edgecolor='black', color='skyblue')  # Histogram with range 0-1500
plt.title('Distribution of Token Lengths')  # Title
plt.xlabel('Token Length')  # X-axis: Token length values
plt.ylabel('Frequency')  # Y-axis: Count of occurrences
plt.grid(True, alpha=0.3)  # Add grid
plt.xlim(0, 1500)  # Set x-axis rang
plt.savefig(local + 'Original_Distribution_of_Token_Lengths.png')


#get trajectory lengths of the previous set:
#load in sub trajectories
with open(previous_dpo_path + "updated_best_worst_experiment_entries-2.json", "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
generated_entries_orig = json.loads(prepared_json2)

#chart the token lengths for the evaluations with "0"
tokens_eval_0 = []
for trajectory in generated_entries_orig:
    for item in trajectory:
        tokens_eval_0.append(item['train_ready_trajectory'])

lengths_b = get_token_lengths(tokens_eval_0, local_model_path)

print("a")

# Create a histogram Distribution_of_Token_Lengths
plt.figure(figsize=(8, 6))  # Set figure size
plt.hist(lengths_b, bins=30, range=(0, 1500), edgecolor='black', color='skyblue')  # Histogram with range 0-1500
plt.title('Distribution of Token Lengths')  # Title
plt.xlabel('Token Length')  # X-axis: Token length values
plt.ylabel('Frequency')  # Y-axis: Count of occurrences
plt.grid(True, alpha=0.3)  # Add grid
plt.xlim(0, 1500)  # Set x-axis rang
plt.savefig(local + 'Original_Distribution_of_Token_Lengths.png')