# In[ ]:
import json
import random
from datasets import Dataset
import os
import shutil

# In[ ]:
local_dir = '/home/peternicholson/Documents/A-3-a-Gsm8k/'
main_dir = '/home/peternicholson/Documents/'

dir_path = local_dir + "/path/to/ppo_dataset"
if os.path.exists(dir_path):
    shutil.rmtree(dir_path)

file_path = local_dir + "dpo_train_set.json"
if os.path.exists(file_path):
    os.remove(file_path)

file_path = local_dir + "vstar_train_set.json"
if os.path.exists(file_path):
    os.remove(file_path)


# In[ ]:
# get evaluation data
file_name = '2-stage2-Gsm8k_filtered_kept_evaluation_log.json'
with open(local_dir + file_name, "r") as file:
    data2 = file.read()
cleaned2 = data2.strip()
prepared_json2 = '[{}]'.format(cleaned2.replace('}{', '},{'))
evaluated_data_load = json.loads(prepared_json2)



#filter out responses that miss actions due to <start_of_turn>model\ missing in initial prompt
for item in evaluated_data_load:
    action = item.get('action')
    if action == "<start_of_turn>model\n":
        evaluated_data_load.remove(item)

print("evaluated_data_no_evalset length: " + str(len(evaluated_data_load)))


# In[ ]:
# sub selection that has a 50/50 split between entries evaluated=1/evaluated=0
eval_1_entries = []
eval_0_entries = []
for item in evaluated_data_load:
    eval_value = item.get('evaluation_value')
    if eval_value == "1":
        eval_1_entries.append(item)
    elif eval_value == "0":
        eval_0_entries.append(item)

# randomize, mix and saved for RL training
random.seed(42)
sampled_eval_1 = random.sample(eval_1_entries, 1000)
sampled_eval_0 = random.sample(eval_0_entries, 1000)
sampled_data = sampled_eval_1 + sampled_eval_0
random.shuffle(sampled_data)


# In[ ]:
#Copy for PPO train
datasetPPO = Dataset.from_list(sampled_data)
total_size = len(datasetPPO)
print("datasetPPO size: " + str(total_size))
datasetPPO.save_to_disk(local_dir + "ppo_dataset")


# In[ ]:
#another copy for DPO train
file_path = local_dir + 'dpo_train_set.json'
if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
    with open(file_path, 'r', encoding="utf-8") as f_file:
        try:
            existing_data = json.load(f_file)
        except json.JSONDecodeError:
            existing_data = []
else:
    existing_data = []

existing_data.extend(sampled_data)
with open(file_path, 'w', encoding="utf-8") as f_file:
    json.dump(existing_data, f_file, indent=1)



#another copy for v_star
file_path = local_dir + 'vstar_train_set.json'
if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
    with open(file_path, 'r', encoding="utf-8") as f_file:
        try:
            existing_data = json.load(f_file)
        except json.JSONDecodeError:
            existing_data = []
else:
    existing_data = []

existing_data.extend(sampled_data)
with open(file_path, 'w', encoding="utf-8") as f_file:
    json.dump(existing_data, f_file, indent=1)






