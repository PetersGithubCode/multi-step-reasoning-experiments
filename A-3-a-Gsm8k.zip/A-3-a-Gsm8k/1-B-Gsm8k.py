# In[ ]:
import json
import re
import ollama
import yaml
import time

# In[ ]:
# load file and setup data in internal data structure
dir_a = '/home/peternicholson/Documents/'

path_filtering_file = dir_a + '1-A-Gsm8k/'
general_path = dir_a + '1-B-Gsm8k/'

# In[ ]:
filtering_model_name = 'gemma3:27b'

# In[ ]:
file = '1-Gsm8k_trajectories_no_filtering.json'
with open(str(path_filtering_file + file), 'r') as file:
    data = file.read()
    cleaned_string = data

# Regex replaces ']' followed by optional whitespace and then '[' with a comma
cleaned_string = re.sub(r'\]\s*\[', ',', cleaned_string)

# Replaced two or more commas with a single one.
cleaned_string = re.sub(r',,+', ',', cleaned_string)

Gsm8k_traj_unfiltered = json.loads(cleaned_string)


# In[ ]:
# FUNCTIONS A: all general functions
# separate the questions and trajectories

def extract_questions_trajectories(f_data):
    # get all contexts as paragraphs in a list of strings
    question_list = []
    trajectories_list = []
    # loop the whole set
    for item in f_data:
        # extract the question also
        question_list.append(item['question'])
        # extract the question also
        trajectories_list.append(item['trajectories'])

    return question_list, trajectories_list


def log_error(f_question, f_error, f_query):
    f_entry = {
        "question": f_question,
        "error:": f_error,
        "query for filtering:": f_query
    }
    with open(general_path + '2-Gsm8k_filtering_error_log.json', 'a', encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)


def log_filtered(f_question, f_current_traj_upto_bad):
    f_entry = {
        "question": f_question,
        "filtered_trajectories": f_current_traj_upto_bad
    }
    with open(general_path + '2-Gsm8k_filtered_out_log.xml', 'a', encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)


def log_filtered_kept(f_question, f_trajectory):
    f_entry = {
        "question": f_question,
        "trajectories": f_trajectory
    }
    with open(general_path + '2-Gsm8k_filtered_kept_log.xml', 'a', encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)


def log_filtered_kept_with_evaluation(f_question, f_trajectory, f_action, f_evaluation, f_evaluation_value):
    f_entry = {
        "question": f_question,
        "trajectories": f_trajectory,
        "action": f_action,
        "evaluation": f_evaluation,
        "evaluation_value": f_evaluation_value
    }
    with open(general_path + '2-stage2-Gsm8k_filtered_kept_evaluation_log.json', 'a', encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)


def build_filtering_query(f_question, f_conversation):
    f_query = (f"<start_of_turn>user\n"
               f"My boss asked me to answer the following question with\n the help of a search engine: {f_question}\n"
               f"This means that I might need to decompose the question into a sequence of searches before being able to answer the question. I am trying to learn how to do this more effectively, so please provide feedback on my last message. Please take a look at our conversation so far: {f_conversation}\n"
               f"When evaluating a message, please only consider the last message and do not penalize or reward me for previous messages. When evaluating an answer, please consider only whether the answer follows from the search results, and not whether you believe the answer to be correct. If there is not enough information from the search results to answer the question, you should rate any answer as \"BAD\". Pay close attention as it may initially seem like the answer is present when it is not. When evaluating a search query, please consider whether it is likely to help me answer the original question. Explain your reasoning and then answer with either \"GOOD\" or \"BAD\". <end_of_turn>\n")
    return f_query


def create_accumulated_sub_trajectories(f_trajectories):
    f_updated_trajectories = []
    f_extracted_actions = []
    x_val = 0
    for a_traj in f_trajectories:

        x_val += 1
        extracted_states, extracted_actions = extract_accumulated_segment(a_traj)
        f_updated_trajectories.append(extracted_states)
        f_extracted_actions.append(extracted_actions)

    return f_updated_trajectories, f_extracted_actions


def extract_accumulated_segment(e_traj):
    pos = 0
    f_acc_trajectories = []
    f_action_traj = []
    eos_flag = False
    while True:
        f_extracted_state, pos, eas_flag, f_action = extract_sub_trajectory(e_traj, pos)
        f_acc_trajectories.append(f_extracted_state)
        f_action_traj.append(f_action)
        if eas_flag:
            break
    return f_acc_trajectories, f_action_traj


def extract_sub_trajectory(f_traj, f_pos):
    f_trajectory = str(f_traj)
    f_eos_encountered = False
    f_extract = ""
    f_start_marker_model = f_trajectory.find("<start_of_turn>model", f_pos)
    if f_start_marker_model == -1:
        f_error = 'Not found <start_of_turn>model'
        # print(f_error)
        # becuase there is a missing next turn go to <eos> and close
        f_action = ""
        f_extracted_state = f_trajectory
        f_eos = True
        new_position = 0
        return f_extracted_state, new_position, f_eos, f_action

    # go from end_marker to the next <end of turn>: the end of state
    f_end_marker_state = f_trajectory.find("<end_of_turn>", f_start_marker_model)
    if f_end_marker_state == -1:
        f_error = 'Not found <end_of_turn> for the model'
        # print(f_error)
        # becuase there is a missing next turn go to <eos> and close
        f_action = ""
        f_extracted_state = f_trajectory
        f_eos = True
        new_position = 0
        return f_extracted_state, new_position, f_eos, f_action

    # when it finds end of turn (<end_of_turn> for the model) then search for <eos> straight after
    if f_end_marker_state != -1:
        # for stage 2. SW RL store the action
        f_action = extract_action(f_start_marker_model, f_end_marker_state, f_trajectory)

        f_extract = f_trajectory[f_end_marker_state:f_end_marker_state + len("<end_of_turn>\n<eos>\n...")]
        # needs to be compared to -1
        if f_extract.find("<eos>") != -1:
            f_eos_encountered = True

    if f_eos_encountered:
        f_content_end = f_end_marker_state + len("<end_of_turn>") + len("<end_of_turn>\n<eos>\n")
    else:
        f_content_end = f_end_marker_state + len("<end_of_turn>")

    f_extracted_state = f_trajectory[:f_content_end]
    new_position = f_content_end

    return f_extracted_state, new_position, f_eos_encountered, f_action


def extract_action(start_pos, end_pos, f_traj):
    return f_traj[start_pos:end_pos]


# In[ ]:
# FUNCTIONS B: #filtering model related functions In[ ]:

def query_the_llm(f_query, f_model_name):
    # post the query, get the response, update the trajectories
    f_response = post_llm(f_query, f_model_name)
    # format the response
    f_formatted_response = format_llm_query_response(f_response)

    return f_response, f_formatted_response


def post_llm(f_query, f_model):
    f_messages = [
        {"role": "user", "content": f_query}
    ]
    f_response = ollama.chat(model=f_model, messages=f_messages, stream=False)
    f_assistant_response = f_response['message']['content']
    # print(f"Assistant: {assistant_response}")

    return f_assistant_response


def format_llm_query_response(f_query):
    f_response = (f"<start_of_turn>model\n"
                  f"{f_query}"
                  f"<end_of_turn>\n")
    return f_response


def evaluate_response(f_response):
    # make it all lowercase
    string_to_clean = f_response.lower()
    # remove astrix and funny punctuation - noticed some responses have ***YES*** or ***NO***
    response_to_check = re.sub(r'[\*\_\[\]\(\)\{\}]', '', string_to_clean)

    # only check the last 70 chars as the response will have an explanation at the beginning
    # last_70_response_to_check = response_to_check[-70:]

    # match them as individual words with space
    f_good = bool(re.search(r'\bgood\b', response_to_check))
    f_bad = bool(re.search(r'\bbad\b', response_to_check))

    if f_good:
        return True
    elif f_bad:
        return False
    else:
        return -1


def evaluate_response_model_check(f_response, f_model_name):
    f_prompt = (
        f"The following response was to rate an answer. Please check the response and return, the word GOOD if the rating was good, the word BAD if the rating was bad or the word NONE if it did not say. Response: {f_response}")
    f_response, f_formatted_response = query_the_llm(f_prompt, f_model_name)

    # make it all lowercase
    string_to_clean = f_response.lower()
    # remove astrix and funny punctuation - noticed some responses have ***YES*** or ***NO***
    response_to_check = re.sub(r'[\*\_\[\]\(\)\{\}]', '', string_to_clean)

    # only check the last 70 chars as the response will have an explanation at the beginning
    # last_70_response_to_check = response_to_check[-70:]

    # match them as individual words with space
    f_good = bool(re.search(r'\bgood\b', response_to_check))
    f_bad = bool(re.search(r'\bbad\b', response_to_check))

    if f_good:
        return 1
    elif f_bad:
        return 0
    else:
        return -1


def log_model_check_eval_response(f_quest, f_state, f_action, f_form_response, f_outcome):
    f_entry = {
        "question": f_quest,
        "trajectories": f_state,
        "action": f_action,
        "evaluation": f_form_response,
        "evaluation_value": f_outcome
    }
    with open(general_path + '2-stage2-Gsm8k_filtered_kept_model_check_evaluation_log.json', 'a',
              encoding="utf-8") as f_file:
        json.dump(f_entry, f_file, indent=1)

    return


# In[ ]:
questions, trajectories = extract_questions_trajectories(Gsm8k_traj_unfiltered)

# In[ ]:
updated_trajectories, updated_actions = create_accumulated_sub_trajectories(trajectories)

# In[ ]:
print(len(updated_trajectories))
# In[ ]:
# save updated traj to file for checkpoint
file_name = "2-Gsm8k_step1_saved_as_trajectory_lists.json"
with open(general_path + file_name, "w") as file:
    json.dump(updated_trajectories, file, indent=4)

# save updated actions to file for checkpoint
file_name = "2-Gsm8k_step1_saved_as_action_lists.json"
with open(general_path + file_name, "w") as file:
    json.dump(updated_actions, file, indent=4)

# In[ ]:
# load files
file_name = "2-Gsm8k_step1_saved_as_trajectory_lists.json"
with open(general_path + file_name, "r") as f:
    lists_of_trajectories = json.load(f)

file_name = "2-Gsm8k_step1_saved_as_action_lists.json"
with open(general_path + file_name, "r") as f:
    lists_of_actions = json.load(f)

# In[ ]:
list_of_lengths = [len(inner_list) for inner_list in lists_of_trajectories]
max_length = max(list_of_lengths)
print(f"Maximum length of k: {max_length}")

# In[ ]:
# easier to see in terminal the progress
traversal_counter = 0
# to show how long for processing
total_start_time = time.time()
for i, i_traj in enumerate(lists_of_trajectories):
    print("i: " + str(i))
    for k, k_state in enumerate(i_traj):
        traversal_counter += 1
        print("traversal_count: " + str(traversal_counter))
        # does k_state have <eos>
        eos = False
        if "<eos>" in str(k_state):
            eos = True

        query_for_filtering = build_filtering_query(str(questions[i]), str(k_state))
        response, formatted_response = query_the_llm(query_for_filtering, filtering_model_name)

        # version which checks the model for evaluation response "GOOD" "BAD" "NONE"
        outcome_from_model_check = evaluate_response_model_check(response, filtering_model_name)
        log_model_check_eval_response(str(questions[i]), str(k_state), str(lists_of_actions[i][k]),
                                      str(formatted_response), str(outcome_from_model_check))

        outcome = evaluate_response(response)
        if outcome == -1:
            error = "No GOOD/BAD: Response: " + response
            # log_error(questions_test[i], error) #TESTING
            log_error(questions[i], error, query_for_filtering)
            log_filtered_kept_with_evaluation(str(questions[i]), str(k_state), str(lists_of_actions[i][k]),
                                              str(formatted_response), str(-1))
            continue
        # to be used later in Stage 2. for Step-wise RL
        # when good save to a separate file made up of the list of successfully traj that also have the response
        if outcome:
            check = lists_of_actions[i][k]
            # save the trajectory with response Good = 1
            log_filtered_kept_with_evaluation(str(questions[i]), str(k_state), str(lists_of_actions[i][k]),
                                              str(formatted_response), str(1))
        if outcome is False:
            # save the trajectory with response Bad = 0
            log_filtered_kept_with_evaluation(str(questions[i]), str(k_state), str(lists_of_actions[i][k]),
                                              str(formatted_response), str(0))

        # Good found and its eos save it, if its eos it will have the whole trajectories for the question
        if outcome and eos:
            log_filtered_kept(str(questions[i]), str(k_state))
            continue

# In[ ]:
# print the end time
print(f"Total processing time: {time.time() - total_start_time:.2f} seconds")
print("reached finish")
